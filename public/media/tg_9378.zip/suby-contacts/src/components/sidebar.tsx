"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { remindersApi } from "@/lib/api";
import { MOCK_REMINDERS } from "@/lib/mock-reminders";

// Tiny inline icon paths (24x24, lucide-style)
const ICONS: Record<string, string> = {
  overview:  "M3 12l9-9 9 9M5 10v10a1 1 0 0 0 1 1h3v-6h6v6h3a1 1 0 0 0 1-1V10",
  inbox:     "M22 12h-6l-2 3h-4l-2-3H2 M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
  contacts:  "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75",
  companies: "M3 21h18 M5 21V7l8-4v18 M19 21V11l-6-4",
  network:   "M18 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M6 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M18 22a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M8.59 13.51l6.83 3.98 M15.41 6.51l-8.82 5.98",
  pipeline:  "M4 6h16 M4 12h10 M4 18h6 M18 12h2 M14 18h6",
  sequences: "M22 11.08V12a10 10 0 1 1-5.93-9.14 M22 4L12 14.01l-3-3",
  prep:      "M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z M16 2v4 M8 2v4 M3 10h18",
  reminders: "M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 5v5l4 2",
  voice:     "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z M19 10v2a7 7 0 0 1-14 0v-2 M12 19v4 M8 23h8",
  settings:  "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z",
};

type NavItem = {
  label: string;
  href: string;
  iconKey: keyof typeof ICONS;
  badgeKey?: "overdue";
};

const SECTIONS: { label: string; items: NavItem[] }[] = [
  {
    label: "Today",
    items: [
      { label: "Overview", href: "/dashboard",      iconKey: "overview" },
      { label: "Inbox",    href: "/dashboard/inbox", iconKey: "inbox" },
    ],
  },
  {
    label: "People",
    items: [
      { label: "Contacts",  href: "/dashboard/contacts",  iconKey: "contacts" },
      { label: "Companies", href: "/dashboard/companies", iconKey: "companies" },
      { label: "Network",   href: "/dashboard/network",   iconKey: "network" },
    ],
  },
  {
    label: "Pipeline",
    items: [
      { label: "Pipeline",  href: "/dashboard/pipeline",  iconKey: "pipeline" },
      { label: "Sequences", href: "/dashboard/sequences", iconKey: "sequences" },
    ],
  },
  {
    label: "Schedule",
    items: [
      { label: "Pre-call",  href: "/dashboard/prep",      iconKey: "prep" },
      { label: "Reminders", href: "/dashboard/reminders", iconKey: "reminders", badgeKey: "overdue" },
      { label: "Voice",     href: "/dashboard/voice",     iconKey: "voice" },
    ],
  },
  {
    label: "System",
    items: [
      { label: "Settings", href: "/dashboard/settings", iconKey: "settings" },
    ],
  },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [overdueCount, setOverdueCount] = useState(0);

  useEffect(() => { setOpen(false); }, [pathname]);

  useEffect(() => {
    const overdueFromMock = MOCK_REMINDERS.filter(
      (r) => r.status === "pending" && new Date(r.dueDate).getTime() < Date.now(),
    ).length;
    remindersApi.getDue()
      .then((r) => setOverdueCount(r.length || overdueFromMock))
      .catch(() => setOverdueCount(overdueFromMock));
  }, []);

  const isActive = (href: string) =>
    href === "/dashboard" ? pathname === "/dashboard" : pathname.startsWith(href);

  const renderLink = (item: NavItem) => {
    const active = isActive(item.href);
    const badge = item.badgeKey === "overdue" ? overdueCount : 0;
    return (
      <Link
        key={item.href}
        href={item.href}
        style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "7px 12px", margin: "0 8px",
          fontSize: 13, fontWeight: active ? 600 : 400,
          textDecoration: "none", borderRadius: 7,
          color: active ? "var(--t1)" : "var(--t2)",
          background: active ? "var(--al)" : "transparent",
          transition: "all 0.12s",
          position: "relative",
        }}
      >
        <svg
          width={15} height={15} viewBox="0 0 24 24" fill="none"
          stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
          style={{ opacity: active ? 0.9 : 0.55, flexShrink: 0 }}
        >
          <path d={ICONS[item.iconKey]} />
        </svg>
        <span style={{ flex: 1 }}>{item.label}</span>
        {badge > 0 && (
          <span style={{
            fontSize: 10, fontWeight: 700, padding: "1px 7px", borderRadius: 10,
            background: "var(--rb)", color: "var(--rc)", lineHeight: "16px",
            minWidth: 18, textAlign: "center",
          }}>
            {badge}
          </span>
        )}
        {active && (
          <span style={{
            position: "absolute", left: -8, top: 6, bottom: 6, width: 2,
            background: "var(--t1)", borderRadius: 2,
          }} />
        )}
      </Link>
    );
  };

  return (
    <>
      {/* Mobile toggle */}
      <button aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}
        className="mobile-menu-btn" style={{
          display: "none", position: "fixed", top: 12, left: 12, zIndex: 60,
          width: 40, height: 40, borderRadius: 8, border: "1px solid var(--bd)",
          background: "var(--sf)", cursor: "pointer", alignItems: "center", justifyContent: "center",
          boxShadow: "var(--shadow)",
        }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          {open ? <><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></> : <><line x1="4" y1="7" x2="20" y2="7" /><line x1="4" y1="12" x2="20" y2="12" /><line x1="4" y1="17" x2="20" y2="17" /></>}
        </svg>
      </button>

      {open && <div className="mobile-overlay" onClick={() => setOpen(false)} style={{ display: "none", position: "fixed", inset: 0, background: "rgba(0,0,0,0.2)", zIndex: 49 }} />}

      <aside className="sidebar" style={{
        position: "fixed", top: 0, left: 0, bottom: 0, width: "var(--sidebar-w)",
        borderRight: "1px solid var(--bd)", background: "var(--sf)",
        paddingTop: 18, paddingBottom: 18, zIndex: 50, overflowY: "auto",
        transition: "transform 0.2s ease",
      }}>
        <div style={{ padding: "0 20px", marginBottom: 18 }}>
          <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: "-0.02em" }}>Suby Contacts</div>
          <div style={{ fontSize: 11, color: "var(--t3)", marginTop: 2 }}>Personal CRM</div>
        </div>

        {SECTIONS.map((section) => (
          <div key={section.label} style={{ marginBottom: 14 }}>
            <div
              className="section-label"
              style={{ padding: "0 20px", marginBottom: 4, fontSize: 10 }}
            >
              {section.label}
            </div>
            <nav style={{ display: "flex", flexDirection: "column", gap: 1 }}>
              {section.items.map(renderLink)}
            </nav>
          </div>
        ))}
      </aside>

      <style>{`
        @media (max-width: 768px) {
          .mobile-menu-btn { display: flex !important; }
          .mobile-overlay { display: block !important; }
          .sidebar { transform: translateX(${open ? "0" : "-100%"}); box-shadow: ${open ? "4px 0 24px rgba(0,0,0,0.08)" : "none"}; }
        }
      `}</style>
    </>
  );
}
