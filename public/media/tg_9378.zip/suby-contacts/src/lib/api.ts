import type { Contact, ContactStats, Tag, ImportJob, Company, Reminder } from "./types";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4002";

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
    cache: "no-store",
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `API error ${res.status}`);
  }

  return res.json();
}

// ─── Contacts API ───────────────────────────────────────────
export const contactsApi = {
  getAll: (params?: { type?: string; domain?: string; search?: string; strength?: string; stale_days?: string; page?: string; limit?: string }) => {
    const qs = params ? "?" + new URLSearchParams(params as Record<string, string>).toString() : "";
    return apiFetch<{ data: Contact[]; total: number; page: number; limit: number }>(`/api/contacts${qs}`);
  },

  getById: (id: string) => apiFetch<Contact>(`/api/contacts/${id}`),

  getStats: () => apiFetch<ContactStats>("/api/contacts/stats"),

  create: (data: Partial<Contact>) =>
    apiFetch<Contact>("/api/contacts", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  update: (id: string, data: Partial<Contact>) =>
    apiFetch<Contact>(`/api/contacts/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    apiFetch<{ success: boolean }>(`/api/contacts/${id}`, { method: "DELETE" }),

  merge: (sourceId: string, targetId: string) =>
    apiFetch<Contact>("/api/contacts/merge", {
      method: "POST",
      body: JSON.stringify({ sourceId, targetId }),
    }),

  enrich: (id: string) =>
    apiFetch<{ contactId: string; enrichedData: Record<string, string>; companyLinked: { id: string; name: string } | null }>(
      `/api/contacts/${id}/enrich`,
      { method: "POST" }
    ),

  addNote: (id: string, content: string) =>
    apiFetch<unknown>(`/api/contacts/${id}/notes`, {
      method: "POST",
      body: JSON.stringify({ content }),
    }),

  deleteNote: (id: string, noteId: string) =>
    apiFetch<{ success: boolean }>(`/api/contacts/${id}/notes/${noteId}`, { method: "DELETE" }),

  addTag: (id: string, tagId: string) =>
    apiFetch<unknown>(`/api/contacts/${id}/tags`, {
      method: "POST",
      body: JSON.stringify({ tagId }),
    }),

  removeTag: (id: string, tagId: string) =>
    apiFetch<{ success: boolean }>(`/api/contacts/${id}/tags/${tagId}`, { method: "DELETE" }),
};

// ─── Tags API ───────────────────────────────────────────────
export const tagsApi = {
  getAll: () => apiFetch<Tag[]>("/api/tags"),

  create: (name: string, color?: string) =>
    apiFetch<Tag>("/api/tags", {
      method: "POST",
      body: JSON.stringify({ name, color }),
    }),
};

// ─── Import API ─────────────────────────────────────────────
export const importApi = {
  getJobs: () => apiFetch<ImportJob[]>("/api/import/jobs"),

  runBeeper: () =>
    apiFetch<ImportJob>("/api/imports/beeper", { method: "POST" }),
};

// ─── Companies API ─────────────────────────────────────────
export const companiesApi = {
  getAll: () => apiFetch<Company[]>("/api/companies"),

  getById: (id: string) => apiFetch<Company>(`/api/companies/${id}`),

  create: (data: Partial<Company>) =>
    apiFetch<Company>("/api/companies", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  update: (id: string, data: Partial<Company>) =>
    apiFetch<Company>(`/api/companies/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  assignContacts: (id: string, contactIds: string[]) =>
    apiFetch<Company>(`/api/companies/${id}/assign`, {
      method: "POST",
      body: JSON.stringify({ contactIds }),
    }),
};

// ─── Reminders API ─────────────────────────────────────────
export const remindersApi = {
  getAll: () => apiFetch<Reminder[]>("/api/reminders"),

  getDue: () => apiFetch<Reminder[]>("/api/reminders/due"),

  create: (contactId: string, data: { content: string; dueDate: string }) =>
    apiFetch<Reminder>(`/api/contacts/${contactId}/reminders`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  update: (id: string, data: Partial<Reminder>) =>
    apiFetch<Reminder>(`/api/reminders/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    apiFetch<{ success: boolean }>(`/api/reminders/${id}`, { method: "DELETE" }),
};

// ─── AI API ─────────────────────────────────────────────────
export const aiApi = {
  classify: (id: string) =>
    apiFetch<{ type: string; domain: string; strength: string }>(`/api/ai/classify/${id}`, { method: "POST" }),

  summary: (id: string) =>
    apiFetch<{ summary: string }>(`/api/ai/summary/${id}`, { method: "POST" }),

  prep: (id: string) =>
    apiFetch<{ briefing: string }>(`/api/ai/prep/${id}`, { method: "POST" }),

  classifyBatch: () =>
    apiFetch<{ queued: number }>("/api/ai/classify-batch", { method: "POST" }),

  alerts: () =>
    apiFetch<{ contactId: string; contactName: string; reason: string }[]>("/api/ai/alerts"),
};
