import Sidebar from "@/components/sidebar";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ display: "flex", minHeight: "100dvh" }}>
      <Sidebar />
      <main className="dash-main" style={{ marginLeft: "var(--sidebar-w)", flex: 1, padding: "24px 28px", overflow: "auto", minWidth: 0 }}>
        {children}
        <style>{`@media (max-width: 768px) { .dash-main { margin-left: 0 !important; padding: 16px !important; padding-top: 64px !important; } }`}</style>
      </main>
    </div>
  );
}
