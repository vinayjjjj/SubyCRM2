"use client";

import { useState, useEffect, use } from "react";
import { useRouter } from "next/navigation";
import { contactsApi, aiApi, tagsApi, remindersApi } from "@/lib/api";
import { MOCK_CONTACTS, MOCK_TAGS } from "@/lib/mock-contacts";
import { MOCK_REMINDERS } from "@/lib/mock-reminders";
import { MOCK_EVENTS, type CalendarEvent } from "@/lib/mock-events";
import type {
  Contact, Tag, ContactType, ContactDomain, RelationshipStrength,
  Reminder, Interaction, Note, PlatformType,
} from "@/lib/types";
import { PlatformIcon } from "@/components/platform-icon";

type TimelineItem =
  | { kind: "interaction"; date: string; data: Interaction }
  | { kind: "note"; date: string; data: Note }
  | { kind: "reminder"; date: string; data: Reminder }
  | { kind: "event"; date: string; data: CalendarEvent };

function buildTimeline(contact: Contact, reminders: Reminder[]): TimelineItem[] {
  const items: TimelineItem[] = [];
  for (const i of contact.interactions || []) items.push({ kind: "interaction", date: i.occurredAt, data: i });
  for (const n of contact.notes || []) items.push({ kind: "note", date: n.createdAt, data: n });
  for (const r of reminders) items.push({ kind: "reminder", date: r.dueDate, data: r });
  for (const e of MOCK_EVENTS.filter((ev) => ev.contactId === contact.id)) {
    items.push({ kind: "event", date: e.start, data: e });
  }
  items.sort((a, b) => +new Date(b.date) - +new Date(a.date));
  return items;
}

const TYPES: ContactType[] = ["vc", "lead", "partner", "friend", "prospect", "team", "advisor", "media", "other"];
const DOMAINS: ContactDomain[] = ["payment", "blockchain", "saas", "ecommerce", "ai", "marketing", "legal", "finance", "other"];
const STRENGTHS: RelationshipStrength[] = ["cold", "warm", "hot"];

const TYPE_COLORS: Record<string, string> = {
  vc: "bdg-p", lead: "bdg-b", partner: "bdg-g", friend: "bdg-y", prospect: "bdg-o",
  team: "bdg-b", advisor: "bdg-p", media: "bdg-o", other: "bdg-b",
};
const DOMAIN_COLORS: Record<string, string> = {
  payment: "bdg-g", blockchain: "bdg-p", saas: "bdg-b", ecommerce: "bdg-o",
  ai: "bdg-p", marketing: "bdg-y", legal: "bdg-r", finance: "bdg-g", other: "bdg-b",
};
const STRENGTH_COLORS: Record<string, string> = { cold: "bdg-b", warm: "bdg-o", hot: "bdg-r" };

const PLATFORM_LINKS: Record<string, (id: string) => string | null> = {
  x: (id) => `https://x.com/${id}`,
  linkedin: (id) => `https://linkedin.com/in/${id}`,
  telegram: (id) => `https://t.me/${id}`,
  whatsapp: () => null,
  discord: () => null,
  slack: () => null,
  email: (id) => `mailto:${id}`,
  matrix: () => null,
};

const HASHTAG_PALETTE = ["#4f46e5", "#dc2626", "#16a34a", "#2563eb", "#ea580c", "#ca8a04"];

function extractHashtags(text: string): string[] {
  const matches = text.match(/#([\p{L}0-9_-]+)/gu) || [];
  return Array.from(new Set(matches.map((m) => m.slice(1))));
}

function renderWithHashtags(text: string): React.ReactNode[] {
  const out: React.ReactNode[] = [];
  const re = /#([\p{L}0-9_-]+)/gu;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    out.push(
      <span
        key={i++}
        style={{
          display: "inline-block",
          padding: "1px 6px",
          margin: "0 1px",
          borderRadius: 4,
          background: "var(--pb)",
          color: "var(--pc)",
          fontSize: 11,
          fontWeight: 600,
        }}
      >
        #{m[1]}
      </span>,
    );
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function relativeDate(dateStr: string | null): string {
  if (!dateStr) return "Never";
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return "Today";
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days}d ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  if (days < 365) return `${Math.floor(days / 30)}mo ago`;
  return `${Math.floor(days / 365)}y ago`;
}

function InlineSelect<T extends string>({ value, options, colorMap, onChange }: {
  value: T; options: T[]; colorMap: Record<string, string>; onChange: (v: T) => void;
}) {
  const [editing, setEditing] = useState(false);

  if (editing) {
    return (
      <select
        value={value}
        autoFocus
        onChange={(e) => { onChange(e.target.value as T); setEditing(false); }}
        onBlur={() => setEditing(false)}
        style={{ fontSize: 12, padding: "2px 6px", borderRadius: "var(--r)", border: "1px solid var(--bd)", background: "var(--sf)" }}
      >
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    );
  }

  return (
    <span
      className={`bdg ${colorMap[value] || "bdg-b"}`}
      style={{ cursor: "pointer" }}
      onClick={() => setEditing(true)}
      title="Click to edit"
    >
      {value}
    </span>
  );
}

export function ContactDetailView({ paramsPromise }: { paramsPromise: Promise<{ id: string }> }) {
  const { id } = use(paramsPromise);
  const router = useRouter();
  const [contact, setContact] = useState<Contact | null>(null);
  const [loading, setLoading] = useState(true);
  const [noteText, setNoteText] = useState("");
  const [addingNote, setAddingNote] = useState(false);
  const [classifying, setClassifying] = useState(false);
  const [summarizing, setSummarizing] = useState(false);
  const [prepping, setPrepping] = useState(false);
  const [prepResult, setPrepResult] = useState<string | null>(null);
  const [allTags, setAllTags] = useState<Tag[]>([]);
  const [selectedTag, setSelectedTag] = useState("");
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [reminderContent, setReminderContent] = useState("");
  const [reminderDate, setReminderDate] = useState("");
  const [addingReminder, setAddingReminder] = useState(false);
  const [enriching, setEnriching] = useState(false);
  const [enrichResult, setEnrichResult] = useState<string | null>(null);

  useEffect(() => {
    const mock = MOCK_CONTACTS.find((c) => c.id === id);
    if (mock) {
      setContact(mock);
      setLoading(false);
    } else {
      contactsApi.getById(id)
        .then(setContact)
        .catch(() => {})
        .finally(() => setLoading(false));
    }
    tagsApi.getAll()
      .then((t) => setAllTags(t.length ? t : MOCK_TAGS))
      .catch(() => setAllTags(MOCK_TAGS));
    loadReminders();
  }, [id]);

  const loadReminders = () => {
    remindersApi.getAll()
      .then((all) => {
        const list = all.length ? all : MOCK_REMINDERS;
        setReminders(list.filter((r) => r.contactId === id));
      })
      .catch(() => setReminders(MOCK_REMINDERS.filter((r) => r.contactId === id)));
  };

  const reload = () => {
    const mock = MOCK_CONTACTS.find((c) => c.id === id);
    if (mock) { setContact(mock); return Promise.resolve(); }
    return contactsApi.getById(id).then(setContact).catch(() => {});
  };

  const handleAddNote = async () => {
    if (!noteText.trim()) return;
    setAddingNote(true);
    const hashtags = extractHashtags(noteText);
    try {
      await contactsApi.addNote(id, noteText.trim());
      // Auto-create + attach extracted hashtags locally (mock-friendly)
      if (hashtags.length > 0) {
        setAllTags((prev) => {
          const existingNames = new Set(prev.map((t) => t.name.toLowerCase()));
          const created = hashtags
            .filter((h) => !existingNames.has(h.toLowerCase()))
            .map((h, i) => ({ id: `tag-${Date.now()}-${i}`, name: h, color: HASHTAG_PALETTE[i % HASHTAG_PALETTE.length], createdAt: new Date().toISOString() }));
          return [...prev, ...created];
        });
        setContact((prev) => {
          if (!prev) return prev;
          const existingTagNames = new Set((prev.contactTags || []).map((ct) => ct.tag?.name.toLowerCase()));
          const newCts = hashtags
            .filter((h) => !existingTagNames.has(h.toLowerCase()))
            .map((h) => ({
              id: `ct-${Date.now()}-${h}`,
              contactId: id,
              tagId: `tag-${h}`,
              tag: { id: `tag-${h}`, name: h, color: HASHTAG_PALETTE[h.length % HASHTAG_PALETTE.length], createdAt: new Date().toISOString() },
              createdAt: new Date().toISOString(),
            }));
          return { ...prev, contactTags: [...(prev.contactTags || []), ...newCts] };
        });
      }
      setNoteText("");
      await reload();
    }
    catch {}
    finally { setAddingNote(false); }
  };

  const handleDeleteNote = async (noteId: string) => {
    try { await contactsApi.deleteNote(id, noteId); await reload(); } catch {}
  };

  const handleClassify = async () => {
    setClassifying(true);
    try { await aiApi.classify(id); await reload(); }
    catch {}
    finally { setClassifying(false); }
  };

  const handleSummary = async () => {
    setSummarizing(true);
    try { await aiApi.summary(id); await reload(); }
    catch {}
    finally { setSummarizing(false); }
  };

  const handlePrep = async () => {
    setPrepping(true);
    setPrepResult(null);
    try {
      const res = await aiApi.prep(id);
      setPrepResult(res.briefing);
    } catch {
      setPrepResult("Failed to generate prep. Try again.");
    } finally {
      setPrepping(false);
    }
  };

  const handleEnrich = async () => {
    setEnriching(true);
    setEnrichResult(null);
    try {
      const res = await contactsApi.enrich(id);
      const parts: string[] = [];
      if (res.enrichedData.role) parts.push(`Role: ${res.enrichedData.role}`);
      if (res.enrichedData.company) parts.push(`Company: ${res.enrichedData.company}`);
      if (res.companyLinked) parts.push(`Linked to company: ${res.companyLinked.name}`);
      setEnrichResult(parts.length > 0 ? parts.join(", ") : "No new data found");
      await reload();
    } catch {
      setEnrichResult("Enrichment failed. Try again.");
    } finally {
      setEnriching(false);
    }
  };

  const handleAddReminder = async () => {
    if (!reminderContent.trim() || !reminderDate) return;
    setAddingReminder(true);
    try {
      await remindersApi.create(id, { content: reminderContent.trim(), dueDate: reminderDate });
      setReminderContent("");
      setReminderDate("");
      loadReminders();
    } catch {}
    finally { setAddingReminder(false); }
  };

  const handleReminderAction = async (reminderId: string, status: "done" | "dismissed") => {
    try {
      await remindersApi.update(reminderId, { status });
      loadReminders();
    } catch {}
  };

  const handleDeleteReminder = async (reminderId: string) => {
    try {
      await remindersApi.delete(reminderId);
      loadReminders();
    } catch {}
  };

  const handleDelete = async () => {
    if (!confirm("Delete this contact?")) return;
    try { await contactsApi.delete(id); router.push("/dashboard/contacts"); }
    catch {}
  };

  const handleFieldChange = async (field: string, value: string) => {
    try { await contactsApi.update(id, { [field]: value } as Partial<Contact>); await reload(); }
    catch {}
  };

  const handleAddTag = async () => {
    if (!selectedTag) return;
    try { await contactsApi.addTag(id, selectedTag); setSelectedTag(""); await reload(); }
    catch {}
  };

  const handleRemoveTag = async (tagId: string) => {
    try { await contactsApi.removeTag(id, tagId); await reload(); } catch {}
  };

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 80 }}>
        <span className="spinner" style={{ width: 20, height: 20, color: "var(--t3)" }} />
      </div>
    );
  }

  if (!contact) {
    return <div className="empty">Contact not found</div>;
  }

  const existingTagIds = new Set(contact.contactTags?.map((ct) => ct.tagId) || []);
  const availableTags = allTags.filter((t) => !existingTagIds.has(t.id));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* Back link */}
      <button className="btn btn-sm" onClick={() => router.push("/dashboard/contacts")} style={{ alignSelf: "flex-start" }}>
        ← Back to contacts
      </button>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
        <div>
          <h1 className="page-title">{contact.name}</h1>
          {(contact.company || contact.role) && (
            <div style={{ fontSize: 14, color: "var(--t2)", marginTop: 4 }}>
              {[contact.role, contact.company].filter(Boolean).join(" @ ")}
            </div>
          )}
          <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap", alignItems: "center" }}>
            <InlineSelect value={contact.type} options={TYPES} colorMap={TYPE_COLORS} onChange={(v) => handleFieldChange("type", v)} />
            <InlineSelect value={contact.domain} options={DOMAINS} colorMap={DOMAIN_COLORS} onChange={(v) => handleFieldChange("domain", v)} />
            <InlineSelect value={contact.relationshipStrength} options={STRENGTHS} colorMap={STRENGTH_COLORS} onChange={(v) => handleFieldChange("relationshipStrength", v)} />
            {contact.contactFrequency != null && contact.contactFrequency > 0 && (
              <span style={{ fontSize: 12, color: "var(--t3)", marginLeft: 4 }}>{contact.contactFrequency} interactions</span>
            )}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button className="btn btn-b btn-sm" onClick={handleClassify} disabled={classifying}>
            {classifying ? "Classifying..." : "Classify (AI)"}
          </button>
          <button className="btn btn-p btn-sm" onClick={handleSummary} disabled={summarizing}>
            {summarizing ? "Summarizing..." : "Summary (AI)"}
          </button>
          <button className="btn btn-sm" onClick={handlePrep} disabled={prepping} style={{ background: "var(--ob)", color: "var(--oc)", border: "1px solid var(--oc)" }}>
            {prepping ? "Generating..." : "Prep (AI)"}
          </button>
          <button className="btn btn-sm" onClick={handleEnrich} disabled={enriching} style={{ background: "var(--gb)", color: "var(--gc)", border: "1px solid var(--gc)" }}>
            {enriching ? "Enriching..." : "Enrich"}
          </button>
          <button className="btn btn-r btn-sm" onClick={handleDelete}>Delete</button>
        </div>
      </div>

      {/* Enrichment result */}
      {enrichResult && (
        <div style={{ padding: "10px 14px", background: "var(--gb)", color: "var(--gc)", borderRadius: "var(--r)", fontSize: 13, fontWeight: 500 }}>
          {enrichResult}
        </div>
      )}

      {/* 2-column grid */}
      <div className="g2" style={{ gap: 20, alignItems: "start" }}>
        {/* Left column */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Platforms */}
          <div className="cd" style={{ padding: 20 }}>
            <div className="section-label" style={{ marginBottom: 12 }}>Platforms</div>
            {contact.platforms && contact.platforms.length > 0 ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {contact.platforms.map((p) => {
                  const linkFn = PLATFORM_LINKS[p.type];
                  const link = p.profileUrl || (linkFn ? linkFn(p.platformId) : null);
                  return (
                    <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", background: "var(--al)", borderRadius: "var(--r)" }}>
                      <PlatformIcon type={p.type} size={18} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13, fontWeight: 500, textTransform: "capitalize" }}>{p.type}</div>
                        {p.displayName && <div style={{ fontSize: 12, color: "var(--t3)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.displayName}</div>}
                      </div>
                      {link && (
                        <a href={link} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} style={{ fontSize: 12, color: "var(--bc)", textDecoration: "none", whiteSpace: "nowrap" }}>
                          Open →
                        </a>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div style={{ color: "var(--t3)", fontSize: 13 }}>No platforms linked</div>
            )}
          </div>

          {/* AI Summary */}
          <div className="cd" style={{ padding: 20 }}>
            <div className="section-label" style={{ marginBottom: 12 }}>AI Summary</div>
            {contact.aiSummary ? (
              <div style={{ fontSize: 13, color: "var(--t2)", lineHeight: 1.6, whiteSpace: "pre-wrap" }}>{contact.aiSummary}</div>
            ) : (
              <div style={{ color: "var(--t3)", fontSize: 13 }}>No AI summary yet. Click "Summary (AI)" to create one.</div>
            )}
          </div>

          {/* Prep Briefing */}
          {prepResult && (
            <div className="cd" style={{ padding: 20, borderLeft: "3px solid var(--oc)" }}>
              <div className="section-label" style={{ marginBottom: 12 }}>Pre-call Briefing</div>
              <div style={{ fontSize: 13, color: "var(--t1)", lineHeight: 1.7, whiteSpace: "pre-wrap" }}>{prepResult}</div>
            </div>
          )}

          {/* Tags */}
          <div className="cd" style={{ padding: 20 }}>
            <div className="section-label" style={{ marginBottom: 12 }}>Tags</div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
              {contact.contactTags && contact.contactTags.length > 0 ? contact.contactTags.map((ct) => (
                <span key={ct.id} className="bdg bdg-b" style={{ cursor: "pointer" }} onClick={() => handleRemoveTag(ct.tagId)}>
                  {ct.tag?.name || ct.tagId} ×
                </span>
              )) : (
                <span style={{ color: "var(--t3)", fontSize: 13 }}>No tags</span>
              )}
            </div>
            {availableTags.length > 0 && (
              <div style={{ display: "flex", gap: 8 }}>
                <select value={selectedTag} onChange={(e) => setSelectedTag(e.target.value)} style={{ flex: 1 }}>
                  <option value="">Select a tag...</option>
                  {availableTags.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
                <button className="btn btn-sm" onClick={handleAddTag}>Add</button>
              </div>
            )}
          </div>
        </div>

        {/* Right column — Unified timeline */}
        <UnifiedTimeline
          contact={contact}
          reminders={reminders}
          noteText={noteText}
          setNoteText={setNoteText}
          addingNote={addingNote}
          onAddNote={handleAddNote}
          onDeleteNote={handleDeleteNote}
          reminderContent={reminderContent}
          setReminderContent={setReminderContent}
          reminderDate={reminderDate}
          setReminderDate={setReminderDate}
          addingReminder={addingReminder}
          onAddReminder={handleAddReminder}
          onReminderAction={handleReminderAction}
          onDeleteReminder={handleDeleteReminder}
        />
      </div>
    </div>
  );
}

function UnifiedTimeline({
  contact, reminders,
  noteText, setNoteText, addingNote, onAddNote, onDeleteNote,
  reminderContent, setReminderContent, reminderDate, setReminderDate,
  addingReminder, onAddReminder, onReminderAction, onDeleteReminder,
}: {
  contact: Contact;
  reminders: Reminder[];
  noteText: string; setNoteText: (v: string) => void; addingNote: boolean;
  onAddNote: () => void; onDeleteNote: (id: string) => void;
  reminderContent: string; setReminderContent: (v: string) => void;
  reminderDate: string; setReminderDate: (v: string) => void;
  addingReminder: boolean; onAddReminder: () => void;
  onReminderAction: (id: string, status: "done" | "dismissed") => void;
  onDeleteReminder: (id: string) => void;
}) {
  const [tab, setTab] = useState<"add" | "note" | "reminder">("add");
  const items = buildTimeline(contact, reminders);

  return (
    <div className="cd" style={{ padding: 0, overflow: "hidden" }}>
      {/* Composer */}
      <div style={{ padding: 16, borderBottom: "1px solid var(--bd)", background: "var(--sf2)" }}>
        <div className="tabs" style={{ margin: 0, marginBottom: tab === "add" ? 0 : 10 }}>
          <button className={`tab ${tab === "add" ? "active" : ""}`} onClick={() => setTab("add")}>+ Add</button>
          <button className={`tab ${tab === "note" ? "active" : ""}`} onClick={() => setTab("note")}>Note</button>
          <button className={`tab ${tab === "reminder" ? "active" : ""}`} onClick={() => setTab("reminder")}>Reminder</button>
        </div>
        {tab === "note" && (
          <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
            <textarea value={noteText} onChange={(e) => setNoteText(e.target.value)} placeholder="Add a note..." rows={2} style={{ flex: 1, resize: "vertical" }} />
            <button className="btn btn-dark btn-sm" onClick={onAddNote} disabled={addingNote} style={{ alignSelf: "flex-end" }}>
              {addingNote ? "Adding..." : "Add"}
            </button>
          </div>
        )}
        {tab === "reminder" && (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}>
            <input value={reminderContent} onChange={(e) => setReminderContent(e.target.value)} placeholder="Reminder content..." style={{ flex: 2, minWidth: 140 }} />
            <input type="date" value={reminderDate} onChange={(e) => setReminderDate(e.target.value)} style={{ flex: 1, minWidth: 120, height: 36, borderRadius: "var(--r)", border: "1px solid var(--bd)", background: "var(--sf)", color: "var(--t1)", fontSize: 13, padding: "0 10px" }} />
            <button className="btn btn-dark btn-sm" onClick={onAddReminder} disabled={addingReminder}>
              {addingReminder ? "Adding..." : "Add"}
            </button>
          </div>
        )}
      </div>

      {/* Timeline */}
      <div style={{ padding: 16 }}>
        <div className="section-label" style={{ marginBottom: 12 }}>
          Timeline
          <span style={{ fontWeight: 400, color: "var(--t3)", marginLeft: 8 }}>({items.length})</span>
        </div>
        {items.length === 0 ? (
          <div className="empty">No activity yet.</div>
        ) : (
          <div style={{ position: "relative", paddingLeft: 24 }}>
            {/* Vertical line */}
            <div style={{
              position: "absolute", left: 11, top: 4, bottom: 4,
              width: 1, background: "var(--bd)",
            }} />
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {items.map((it, idx) => (
                <TimelineRow
                  key={`${it.kind}-${idx}`}
                  item={it}
                  onDeleteNote={onDeleteNote}
                  onReminderAction={onReminderAction}
                  onDeleteReminder={onDeleteReminder}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function TimelineRow({
  item, onDeleteNote, onReminderAction, onDeleteReminder,
}: {
  item: TimelineItem;
  onDeleteNote: (id: string) => void;
  onReminderAction: (id: string, status: "done" | "dismissed") => void;
  onDeleteReminder: (id: string) => void;
}) {
  if (item.kind === "interaction") {
    const i = item.data;
    return (
      <TimelineFrame
        dotColor={i.direction === "inbound" ? "var(--gc)" : "var(--bc)"}
        dotIcon={<PlatformIcon type={i.platform} size={11} />}
        date={item.date}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
          <span style={{ fontSize: 12, fontWeight: 500, textTransform: "capitalize" }}>{i.platform}</span>
          <span
            style={{
              fontSize: 9, fontWeight: 700, padding: "1px 5px", borderRadius: 4,
              background: i.direction === "inbound" ? "var(--gb)" : "var(--bb)",
              color: i.direction === "inbound" ? "var(--gc)" : "var(--bc)",
            }}
          >
            {i.direction === "inbound" ? "IN" : "OUT"}
          </span>
          {i.messageCount > 1 && (
            <span style={{ fontSize: 10, color: "var(--t3)" }}>· {i.messageCount} msgs</span>
          )}
        </div>
        {i.contentSnippet && (
          <div style={{ fontSize: 12, color: "var(--t2)", lineHeight: 1.4 }}>{i.contentSnippet}</div>
        )}
      </TimelineFrame>
    );
  }

  if (item.kind === "note") {
    const n = item.data;
    return (
      <TimelineFrame
        dotColor="var(--yc)"
        dotIcon={
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ color: "var(--yc)" }}>
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
          </svg>
        }
        date={item.date}
        background="var(--yb)"
        borderColor="#f5e1a0"
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
          <span style={{ fontSize: 11, fontWeight: 600, color: "var(--yc)", textTransform: "uppercase", letterSpacing: 0.04 }}>
            Note
          </span>
          <button
            onClick={() => onDeleteNote(n.id)}
            style={{ fontSize: 10, color: "var(--t3)", background: "none", border: "none", cursor: "pointer", padding: 0 }}
          >
            Remove
          </button>
        </div>
        <div style={{ fontSize: 12, color: "var(--t1)", lineHeight: 1.5, whiteSpace: "pre-wrap" }}>{renderWithHashtags(n.content)}</div>
      </TimelineFrame>
    );
  }

  if (item.kind === "reminder") {
    const r = item.data;
    const isFuture = new Date(r.dueDate).getTime() > Date.now();
    const isOverdue = r.status === "pending" && !isFuture;
    const isDone = r.status === "done";
    const dotColor = isDone ? "var(--gc)" : isOverdue ? "var(--rc)" : "var(--oc)";
    return (
      <TimelineFrame
        dotColor={dotColor}
        dotIcon={
          isDone ? (
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          ) : (
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke={dotColor} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          )
        }
        date={r.dueDate}
        background={isOverdue ? "var(--rb)" : isDone ? "var(--sf2)" : "var(--ob)"}
        borderColor={isOverdue ? "var(--rc)" : isDone ? "var(--bd)" : "var(--oc)"}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
          <span
            style={{
              fontSize: 11, fontWeight: 600, color: dotColor,
              textTransform: "uppercase", letterSpacing: 0.04,
            }}
          >
            {isDone ? "Done reminder" : isOverdue ? "Overdue reminder" : isFuture ? "Reminder" : "Reminder"}
          </span>
          {r.status === "pending" && (
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => onReminderAction(r.id, "done")} style={{ fontSize: 10, fontWeight: 600, color: "var(--gc)", background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                Done
              </button>
              <button onClick={() => onReminderAction(r.id, "dismissed")} style={{ fontSize: 10, color: "var(--t3)", background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                Dismiss
              </button>
              <button onClick={() => onDeleteReminder(r.id)} style={{ fontSize: 10, color: "var(--rc)", background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                Delete
              </button>
            </div>
          )}
        </div>
        <div style={{ fontSize: 12, color: "var(--t1)", lineHeight: 1.4, textDecoration: isDone ? "line-through" : "none" }}>
          {r.content}
        </div>
      </TimelineFrame>
    );
  }

  if (item.kind === "event") {
    const e = item.data;
    const start = new Date(e.start);
    const end = new Date(e.end);
    const time = `${start.getHours().toString().padStart(2, "0")}:${start.getMinutes().toString().padStart(2, "0")}–${end.getHours().toString().padStart(2, "0")}:${end.getMinutes().toString().padStart(2, "0")}`;
    return (
      <TimelineFrame
        dotColor="var(--pc)"
        dotIcon={
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--pc)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
            <line x1="16" y1="2" x2="16" y2="6" />
            <line x1="8" y1="2" x2="8" y2="6" />
            <line x1="3" y1="10" x2="21" y2="10" />
          </svg>
        }
        date={item.date}
        background="var(--pb)"
        borderColor="var(--pc)"
      >
        <div style={{ fontSize: 11, fontWeight: 600, color: "var(--pc)", textTransform: "uppercase", letterSpacing: 0.04, marginBottom: 2 }}>
          Call · {e.channel.replace("_", " ")}
        </div>
        <div style={{ fontSize: 12, fontWeight: 500, color: "var(--t1)" }}>{e.title}</div>
        <div className="mono" style={{ fontSize: 10, color: "var(--t3)", marginTop: 2 }}>{time}</div>
      </TimelineFrame>
    );
  }

  return null;
}

function TimelineFrame({
  dotColor, dotIcon, date, background, borderColor, children,
}: {
  dotColor: string;
  dotIcon: React.ReactNode;
  date: string;
  background?: string;
  borderColor?: string;
  children: React.ReactNode;
}) {
  return (
    <div style={{ position: "relative" }}>
      <div
        style={{
          position: "absolute", left: -19, top: 6,
          width: 18, height: 18, borderRadius: "50%",
          background: "var(--sf)",
          border: `2px solid ${dotColor}`,
          display: "flex", alignItems: "center", justifyContent: "center",
          zIndex: 1,
        }}
      >
        {dotIcon}
      </div>
      <div
        style={{
          padding: "8px 12px",
          background: background || "var(--sf2)",
          border: `1px solid ${borderColor || "var(--bd)"}`,
          borderRadius: 8,
        }}
      >
        {children}
        <div className="mono" style={{ fontSize: 10, color: "var(--t3)", marginTop: 4 }}>
          {relativeDate(date)}
        </div>
      </div>
    </div>
  );
}
