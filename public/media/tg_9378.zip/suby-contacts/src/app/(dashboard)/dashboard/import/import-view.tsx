"use client";

import { useState, useEffect } from "react";
import { importApi, aiApi } from "@/lib/api";
import { MOCK_IMPORT_JOBS } from "@/lib/mock-contacts";
import type { ImportJob } from "@/lib/types";

function relativeDate(dateStr: string | null): string {
  if (!dateStr) return "--";
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return "Today";
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days}d ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

const STATUS_BADGE: Record<string, string> = {
  completed: "bdg-g", failed: "bdg-r", running: "bdg-b", pending: "bdg-y",
};

const SOURCES = [
  {
    key: "beeper",
    name: "Beeper / Matrix",
    description: "Import contacts from Beeper unified inbox or any Matrix-based client. Pulls all bridged conversations.",
    icon: "M",
    color: "var(--pc)",
    bg: "var(--pb)",
    status: "ready",
  },
  {
    key: "whatsapp",
    name: "WhatsApp",
    description: "Import from WhatsApp chat export. Upload a .txt or .zip file exported from WhatsApp.",
    icon: "W",
    color: "#25D366",
    bg: "#25D36615",
    status: "coming_soon",
  },
  {
    key: "telegram",
    name: "Telegram",
    description: "Connect via Telegram API to import contacts and recent conversations automatically.",
    icon: "T",
    color: "#229ED9",
    bg: "#229ED915",
    status: "coming_soon",
  },
  {
    key: "discord",
    name: "Discord",
    description: "Import DM contacts and server members from Discord using a bot token.",
    icon: "D",
    color: "#5865F2",
    bg: "#5865F215",
    status: "coming_soon",
  },
  {
    key: "slack",
    name: "Slack",
    description: "Import workspace members and DM contacts from Slack using an OAuth token.",
    icon: "S",
    color: "#E01E5A",
    bg: "#E01E5A15",
    status: "coming_soon",
  },
];

export function ImportView() {
  const [jobs, setJobs] = useState<ImportJob[]>([]);
  const [importing, setImporting] = useState(false);
  const [classifying, setClassifying] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const loadJobs = () => {
    importApi.getJobs()
      .then((j) => setJobs(j?.length ? j : MOCK_IMPORT_JOBS))
      .catch(() => setJobs(MOCK_IMPORT_JOBS));
  };

  useEffect(() => { loadJobs(); }, []);

  const handleBeeperImport = async () => {
    setImporting(true);
    setMessage(null);
    try {
      const job = await importApi.runBeeper();
      setMessage({ text: `Beeper import started (job ${job.id.slice(0, 8)})`, type: "success" });
      // Poll for completion
      const poll = setInterval(() => {
        importApi.getJobs().then((j) => {
          setJobs(j);
          const current = j.find((x) => x.id === job.id);
          if (current && (current.status === "completed" || current.status === "failed")) {
            clearInterval(poll);
            if (current.status === "completed") {
              setMessage({ text: `Import complete: ${current.imported ?? 0} imported, ${current.deduplicated ?? 0} deduplicated`, type: "success" });
            } else {
              setMessage({ text: "Import failed. Check logs.", type: "error" });
            }
          }
        });
      }, 3000);
      setTimeout(() => clearInterval(poll), 120000);
    } catch {
      setMessage({ text: "Failed to start import. Is the backend running?", type: "error" });
    } finally {
      setImporting(false);
    }
  };

  const handleClassifyAll = async () => {
    setClassifying(true);
    setMessage(null);
    try {
      const res = await aiApi.classifyBatch();
      setMessage({ text: `Queued ${res.queued} contacts for AI classification`, type: "success" });
    } catch {
      setMessage({ text: "Classification failed.", type: "error" });
    } finally {
      setClassifying(false);
    }
  };

  const lastCompleted = jobs.find((j) => j.status === "completed");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 className="page-title">Import</h1>
          <p style={{ color: "var(--t2)", fontSize: 13, marginTop: 4 }}>Import contacts from your messaging platforms</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-p btn-sm" onClick={handleClassifyAll} disabled={classifying}>
            {classifying ? "Classifying..." : "Classify All (AI)"}
          </button>
        </div>
      </div>

      {message && (
        <div style={{
          padding: "10px 14px", borderRadius: "var(--r)", fontSize: 13, fontWeight: 500,
          background: message.type === "success" ? "var(--gb)" : "var(--rb)",
          color: message.type === "success" ? "var(--gc)" : "var(--rc)",
        }}>
          {message.text}
        </div>
      )}

      {/* Last import stats */}
      {lastCompleted && (
        <div className="cd" style={{ padding: 16 }}>
          <div className="section-label" style={{ marginBottom: 10 }}>Last Import Summary</div>
          <div className="g4" style={{ gap: 12 }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: "var(--t1)" }}>{lastCompleted.totalFound ?? 0}</div>
              <div style={{ fontSize: 11, color: "var(--t3)" }}>Found</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: "var(--gc)" }}>{lastCompleted.imported ?? 0}</div>
              <div style={{ fontSize: 11, color: "var(--t3)" }}>Imported</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: "var(--oc)" }}>{lastCompleted.deduplicated ?? 0}</div>
              <div style={{ fontSize: 11, color: "var(--t3)" }}>Deduplicated</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: lastCompleted.errors ? "var(--rc)" : "var(--t1)" }}>{lastCompleted.errors ?? 0}</div>
              <div style={{ fontSize: 11, color: "var(--t3)" }}>Errors</div>
            </div>
          </div>
        </div>
      )}

      {/* Source cards */}
      <div className="g3" style={{ gap: 16 }}>
        {SOURCES.map((s) => (
          <div key={s.key} className="cd" style={{ padding: 20, display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{
                width: 36, height: 36, borderRadius: 8, background: s.bg, color: s.color,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontWeight: 700, fontSize: 16,
              }}>
                {s.icon}
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{s.name}</div>
              </div>
            </div>
            <div style={{ fontSize: 13, color: "var(--t2)", lineHeight: 1.5 }}>{s.description}</div>
            <div style={{ marginTop: "auto" }}>
              {s.status === "ready" ? (
                <button
                  className="btn btn-dark btn-sm"
                  onClick={handleBeeperImport}
                  disabled={importing}
                  style={{ width: "100%" }}
                >
                  {importing ? "Importing..." : "Run Beeper Import"}
                </button>
              ) : (
                <span className="bdg bdg-y">Coming soon</span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Recent import jobs */}
      {jobs.length > 0 && (
        <div className="cd" style={{ padding: 20 }}>
          <div className="section-label" style={{ marginBottom: 12 }}>Import History</div>
          <table>
            <thead>
              <tr>
                <th>Source</th>
                <th>Status</th>
                <th>Found</th>
                <th>Imported</th>
                <th>Dedup</th>
                <th>Errors</th>
                <th className="hide-mobile">Date</th>
              </tr>
            </thead>
            <tbody>
              {jobs
                .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                .map((j) => (
                <tr key={j.id}>
                  <td style={{ fontWeight: 500, textTransform: "capitalize" }}>{j.source.replace("_", " ")}</td>
                  <td>
                    <span className={`bdg ${STATUS_BADGE[j.status] || "bdg-y"}`}>
                      {j.status}
                    </span>
                  </td>
                  <td className="mono">{j.totalFound ?? "--"}</td>
                  <td className="mono">{j.imported ?? "--"}</td>
                  <td className="mono">{j.deduplicated ?? "--"}</td>
                  <td className="mono" style={{ color: j.errors ? "var(--rc)" : undefined }}>{j.errors ?? "--"}</td>
                  <td className="hide-mobile mono" style={{ fontSize: 12, color: "var(--t3)" }}>{relativeDate(j.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
