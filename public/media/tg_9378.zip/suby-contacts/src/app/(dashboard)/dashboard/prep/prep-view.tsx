"use client";

import { useState, useMemo, useEffect } from "react";
import { MOCK_EVENTS, type CalendarEvent, type CallChannel } from "@/lib/mock-events";
import { MOCK_CONTACTS, buildBriefing } from "@/lib/mock-contacts";
import type { Contact } from "@/lib/types";

const HOUR_START = 8;
const HOUR_END = 20;
const HOUR_HEIGHT = 48; // px per hour
const DAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const CHANNEL_META: Record<CallChannel, { label: string; bg: string; color: string; icon: string }> = {
  zoom: { label: "Zoom", bg: "#2D8CFF15", color: "#2D8CFF", icon: "🎥" },
  meet: { label: "Google Meet", bg: "#34A85315", color: "#34A853", icon: "📹" },
  phone: { label: "Phone call", bg: "var(--gb)", color: "var(--gc)", icon: "📞" },
  in_person: { label: "In person", bg: "var(--ob)", color: "var(--oc)", icon: "🤝" },
  telegram: { label: "Telegram", bg: "#229ED915", color: "#229ED9", icon: "✈️" },
  x_space: { label: "X Space", bg: "var(--al)", color: "var(--t1)", icon: "🎙️" },
};

const CONTACT_LOOKUP: Record<string, Contact> = Object.fromEntries(
  MOCK_CONTACTS.map((c) => [c.id, c]),
);

function startOfWeek(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  const day = (x.getDay() + 6) % 7;
  x.setDate(x.getDate() - day);
  return x;
}

function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

function fmtRange(start: Date, end: Date): string {
  const sameMonth = start.getMonth() === end.getMonth();
  const s = start.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  const e = end.toLocaleDateString(undefined, {
    month: sameMonth ? undefined : "short",
    day: "numeric",
    year: "numeric",
  });
  return `${s} – ${e}`;
}

function fmtTime(d: Date): string {
  return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
}

function initials(name: string): string {
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || "").join("");
}

function eventTone(channel: CallChannel): { bg: string; border: string; color: string } {
  const meta = CHANNEL_META[channel];
  return { bg: meta.bg, border: meta.color, color: meta.color };
}

export function PrepView() {
  const [weekStart, setWeekStart] = useState(() => startOfWeek(new Date()));
  const [selected, setSelected] = useState<CalendarEvent | null>(null);

  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)), [weekStart]);
  const weekEnd = useMemo(() => addDays(weekStart, 6), [weekStart]);

  const eventsByDay = useMemo(() => {
    const map: Record<number, CalendarEvent[]> = {};
    for (let i = 0; i < 7; i++) map[i] = [];
    for (const e of MOCK_EVENTS) {
      const start = new Date(e.start);
      for (let i = 0; i < 7; i++) {
        if (start.toDateString() === days[i].toDateString()) {
          map[i].push(e);
          break;
        }
      }
    }
    for (const k of Object.keys(map)) {
      map[+k].sort((a, b) => +new Date(a.start) - +new Date(b.start));
    }
    return map;
  }, [days]);

  const totalEvents = Object.values(eventsByDay).reduce((s, v) => s + v.length, 0);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Lock body scroll when modal open
  useEffect(() => {
    if (selected) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => { document.body.style.overflow = prev; };
    }
  }, [selected]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 className="page-title">Pre-call</h1>
          <p style={{ color: "var(--t2)", fontSize: 13, marginTop: 4 }}>
            {totalEvents} call{totalEvents !== 1 ? "s" : ""} this week
          </p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button className="btn btn-sm" onClick={() => setWeekStart(addDays(weekStart, -7))}>← Prev</button>
          <button className="btn btn-sm" onClick={() => setWeekStart(startOfWeek(new Date()))}>This week</button>
          <button className="btn btn-sm" onClick={() => setWeekStart(addDays(weekStart, 7))}>Next →</button>
          <span style={{ fontSize: 13, color: "var(--t2)", marginLeft: 8, fontWeight: 500 }}>
            {fmtRange(weekStart, weekEnd)}
          </span>
        </div>
      </div>

      <div className="cd" style={{ overflow: "auto" }}>
        <div className="agenda">
          {/* Day headers */}
          <div className="agenda-corner" />
          {days.map((d, i) => {
            const isToday = d.getTime() === today.getTime();
            return (
              <div key={i} className="agenda-dayhead" style={{ background: isToday ? "var(--bb)" : "var(--sf2)" }}>
                <div style={{ fontSize: 11, color: isToday ? "var(--bc)" : "var(--t3)", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.04 }}>
                  {DAY_LABELS[i]}
                </div>
                <div style={{ fontSize: 16, color: isToday ? "var(--bc)" : "var(--t1)", fontWeight: 700, marginTop: 2 }}>
                  {d.getDate()}
                </div>
              </div>
            );
          })}

          {/* Hour rows + day columns */}
          <div className="agenda-times">
            {Array.from({ length: HOUR_END - HOUR_START }, (_, i) => {
              const h = HOUR_START + i;
              return (
                <div key={h} className="agenda-time" style={{ height: HOUR_HEIGHT }}>
                  <span>{h.toString().padStart(2, "0")}:00</span>
                </div>
              );
            })}
          </div>

          {days.map((d, dayIdx) => {
            const isToday = d.getTime() === today.getTime();
            return (
              <div key={dayIdx} className="agenda-day" style={{ height: HOUR_HEIGHT * (HOUR_END - HOUR_START), background: isToday ? "rgba(37,99,235,0.03)" : "transparent" }}>
                {/* Hour gridlines */}
                {Array.from({ length: HOUR_END - HOUR_START }, (_, i) => (
                  <div key={i} className="agenda-gridline" style={{ top: i * HOUR_HEIGHT }} />
                ))}

                {/* Events */}
                {eventsByDay[dayIdx].map((e) => {
                  const start = new Date(e.start);
                  const end = new Date(e.end);
                  const hourFromStart = start.getHours() + start.getMinutes() / 60 - HOUR_START;
                  const durHours = (end.getTime() - start.getTime()) / 3600000;
                  const top = hourFromStart * HOUR_HEIGHT;
                  const height = Math.max(30, durHours * HOUR_HEIGHT - 2);
                  const tone = eventTone(e.channel);
                  return (
                    <button
                      key={e.id}
                      onClick={() => setSelected(e)}
                      className="agenda-event"
                      style={{
                        top,
                        height,
                        background: tone.bg,
                        borderLeft: `3px solid ${tone.border}`,
                      }}
                    >
                      <div style={{ fontSize: 11, fontWeight: 600, color: "var(--t1)", lineHeight: 1.25, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {e.title}
                      </div>
                      <div style={{ fontSize: 10, color: "var(--t2)", marginTop: 1 }}>
                        {fmtTime(start)} · {e.contactName}
                      </div>
                    </button>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>

      {selected && (
        <EventModal event={selected} onClose={() => setSelected(null)} />
      )}

      <style jsx>{`
        .agenda {
          display: grid;
          grid-template-columns: 56px repeat(7, minmax(120px, 1fr));
          grid-template-rows: 56px auto;
          min-width: 880px;
        }
        .agenda-corner {
          background: var(--sf2);
          border-bottom: 1px solid var(--bd);
          border-right: 1px solid var(--bd);
        }
        .agenda-dayhead {
          padding: 8px 12px;
          border-bottom: 1px solid var(--bd);
          border-right: 1px solid var(--bd);
          text-align: left;
        }
        .agenda-dayhead:last-child {
          border-right: none;
        }
        .agenda-times {
          border-right: 1px solid var(--bd);
          position: relative;
        }
        .agenda-time {
          font-size: 10px;
          color: var(--t3);
          font-variant-numeric: tabular-nums;
          padding: 2px 6px 0 0;
          text-align: right;
          border-bottom: 1px dashed transparent;
          position: relative;
        }
        .agenda-time span {
          position: relative;
          top: -6px;
        }
        .agenda-day {
          position: relative;
          border-right: 1px solid var(--bd);
        }
        .agenda-day:last-child {
          border-right: none;
        }
        .agenda-gridline {
          position: absolute;
          left: 0;
          right: 0;
          border-bottom: 1px solid var(--bd);
          height: 0;
        }
        .agenda-event {
          position: absolute;
          left: 4px;
          right: 4px;
          padding: 4px 8px;
          border-radius: 6px;
          border: 1px solid transparent;
          cursor: pointer;
          text-align: left;
          overflow: hidden;
          transition: box-shadow 0.12s, transform 0.12s;
        }
        .agenda-event:hover {
          box-shadow: var(--shadow);
          transform: translateY(-1px);
        }
      `}</style>
    </div>
  );
}

function EventModal({
  event,
  onClose,
}: {
  event: CalendarEvent;
  onClose: () => void;
}) {
  const contact = CONTACT_LOOKUP[event.contactId];
  const start = new Date(event.start);
  const end = new Date(event.end);
  const channelMeta = CHANNEL_META[event.channel];
  const isLink = event.location && /^https?:\/\//.test(event.location);

  const briefing = useMemo(
    () => (contact ? buildBriefing(contact) : "Pre-qualification unavailable."),
    [contact],
  );
  const sections = useMemo(() => parseBriefing(briefing), [briefing]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)",
        display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: 100, padding: 20,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "var(--sf)", borderRadius: 16, boxShadow: "0 12px 40px rgba(0,0,0,0.18)",
          width: "100%", maxWidth: 560, maxHeight: "85vh", overflow: "hidden",
          display: "flex", flexDirection: "column",
        }}
      >
        {/* Header */}
        <div style={{ padding: "18px 22px", borderBottom: "1px solid var(--bd)", display: "flex", alignItems: "flex-start", gap: 12 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 11, color: "var(--t3)", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.04 }}>
              {start.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" })} · {fmtTime(start)}–{fmtTime(end)}
            </div>
            <div style={{ fontSize: 20, fontWeight: 700, color: "var(--t1)", letterSpacing: "-0.02em", marginTop: 2 }}>
              {event.contactName}
            </div>
            {contact && [contact.role, contact.company].filter(Boolean).length > 0 && (
              <div style={{ fontSize: 12, color: "var(--t2)", marginTop: 2 }}>
                {[contact.role, contact.company].filter(Boolean).join(" @ ")}
              </div>
            )}
          </div>
          <button
            aria-label="Close"
            onClick={onClose}
            style={{
              background: "var(--al)", border: "none", color: "var(--t2)",
              width: 30, height: 30, borderRadius: 8,
              display: "flex", alignItems: "center", justifyContent: "center",
              cursor: "pointer", flexShrink: 0,
            }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div style={{ overflowY: "auto", padding: "18px 22px", display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Call link / channel */}
          {isLink ? (
            <a
              href={event.location}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: "flex", alignItems: "center", gap: 12,
                padding: "12px 14px",
                background: channelMeta.bg, borderRadius: 10,
                border: `1px solid ${channelMeta.color}30`,
                textDecoration: "none",
                transition: "border-color 0.12s",
              }}
            >
              <span style={{ fontSize: 22 }}>{channelMeta.icon}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "var(--t1)" }}>
                  Join {channelMeta.label}
                </div>
                <div className="mono" style={{ fontSize: 11, color: "var(--t2)", marginTop: 2, wordBreak: "break-all" }}>
                  {event.location}
                </div>
              </div>
              <span style={{ fontSize: 13, color: channelMeta.color, fontWeight: 600 }}>→</span>
            </a>
          ) : (
            <div
              style={{
                display: "flex", alignItems: "center", gap: 12,
                padding: "12px 14px",
                background: channelMeta.bg, borderRadius: 10,
                border: `1px solid ${channelMeta.color}30`,
              }}
            >
              <span style={{ fontSize: 22 }}>{channelMeta.icon}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "var(--t1)" }}>{channelMeta.label}</div>
                {event.location && (
                  <div style={{ fontSize: 12, color: "var(--t2)", marginTop: 2 }}>{event.location}</div>
                )}
              </div>
            </div>
          )}

          {/* Pre-qualification */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <div className="section-label">Pre-qualification</div>
              <span className="bdg bdg-p" style={{ fontSize: 10 }}>AI</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {sections.filter((s) => s.content.trim()).map((s, i) => (
                <div
                  key={i}
                  style={{
                    padding: "10px 14px",
                    background: "var(--sf2)",
                    border: "1px solid var(--bd)",
                    borderRadius: 8,
                  }}
                >
                  {s.title && (
                    <div style={{ fontSize: 12, fontWeight: 600, color: "var(--t1)", marginBottom: 4 }}>
                      {s.title}
                    </div>
                  )}
                  <div style={{ fontSize: 12, color: "var(--t2)", lineHeight: 1.6, whiteSpace: "pre-wrap" }}>
                    {s.content}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function parseBriefing(text: string): { title: string; content: string }[] {
  const sections: { title: string; content: string }[] = [];
  const lines = text.split("\n");
  let title = "";
  let buf: string[] = [];
  for (const line of lines) {
    const m = line.match(/^#{1,3}\s+(.+)/) || line.match(/^\*\*(.+?)\*\*\s*$/);
    if (m) {
      if (title || buf.length) sections.push({ title, content: buf.join("\n").trim() });
      title = m[1].replace(/\*\*/g, "").trim();
      buf = [];
    } else {
      buf.push(line);
    }
  }
  if (title || buf.length) sections.push({ title, content: buf.join("\n").trim() });
  return sections.length ? sections : [{ title: "", content: text }];
}
