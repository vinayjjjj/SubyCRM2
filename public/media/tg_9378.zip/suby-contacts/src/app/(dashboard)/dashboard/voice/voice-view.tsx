"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import {
  MOCK_VOICE_CAPTURES,
  ACTION_META,
  STATUS_META,
  SIMULATOR_TEMPLATES,
  type VoiceCapture,
  type ExtractedAction,
} from "@/lib/mock-voice-captures";
import { MOCK_CONTACTS } from "@/lib/mock-contacts";

function fmtAgo(iso: string): string {
  const diffMin = (Date.now() - new Date(iso).getTime()) / 60000;
  if (diffMin < 1) return "just now";
  if (diffMin < 60) return `${Math.round(diffMin)}m ago`;
  const h = diffMin / 60;
  if (h < 24) return `${Math.round(h)}h ago`;
  return `${Math.round(h / 24)}d ago`;
}

function fmtDue(iso?: string | null): string {
  if (!iso) return "";
  const days = Math.round((new Date(iso).getTime() - Date.now()) / 86400000);
  if (days === 0) return "Today";
  if (days === 1) return "Tomorrow";
  if (days < 0) return `${-days}d ago`;
  return `In ${days}d`;
}

function initials(name: string | null): string {
  if (!name) return "??";
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || "").join("");
}

function fakeWave(seed: number, bars = 36): number[] {
  // Deterministic pseudo-random heights for the waveform
  const out: number[] = [];
  let s = seed;
  for (let i = 0; i < bars; i++) {
    s = (s * 9301 + 49297) % 233280;
    out.push(0.3 + (s / 233280) * 0.7);
  }
  return out;
}

export function VoiceView() {
  const router = useRouter();
  const [captures, setCaptures] = useState<VoiceCapture[]>(MOCK_VOICE_CAPTURES);
  const [expanded, setExpanded] = useState<string | null>(captures[0]?.id ?? null);
  const [simulating, setSimulating] = useState<{ template: number; step: "uploading" | "transcribing" | "extracting" | null } | null>(null);

  const counts = useMemo(() => ({
    total: captures.length,
    processed: captures.filter((c) => c.status === "processed").length,
    needsOk: captures.filter((c) => c.status === "needs_confirmation").length,
    failed: captures.filter((c) => c.status === "failed").length,
    actions: captures.reduce((s, c) => s + c.actions.filter((a) => a.kind !== "no_action").length, 0),
  }), [captures]);

  const runSimulation = async (idx: number) => {
    const tpl = SIMULATOR_TEMPLATES[idx];
    if (!tpl) return;
    setSimulating({ template: idx, step: "uploading" });
    await new Promise((r) => setTimeout(r, 600));
    setSimulating({ template: idx, step: "transcribing" });
    await new Promise((r) => setTimeout(r, 900));
    setSimulating({ template: idx, step: "extracting" });
    await new Promise((r) => setTimeout(r, 800));

    const contact = MOCK_CONTACTS.find((c) => c.id === tpl.contactId);
    const newCapture: VoiceCapture = {
      id: `vc-sim-${Date.now()}`,
      receivedAt: new Date().toISOString(),
      durationSec: 8 + idx * 2,
      transcript: tpl.transcript,
      status: "processed",
      processingMs: 2300,
      actions: tpl.build({ contactId: tpl.contactId, contactName: contact?.name ?? null }),
    };
    setCaptures((prev) => [newCapture, ...prev]);
    setExpanded(newCapture.id);
    setSimulating(null);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 22, maxWidth: 980 }}>
      <div>
        <h1 className="page-title">Voice capture</h1>
        <p style={{ color: "var(--t2)", fontSize: 13, marginTop: 4 }}>
          Send voice notes to{" "}
          <a
            href="https://t.me/subyassist_bot"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "var(--bc)", textDecoration: "none", fontWeight: 500 }}
          >
            @subyassist_bot
          </a>{" "}
          . Whisper transcribes, Claude extracts notes / reminders / strength bumps.
        </p>
      </div>

      {/* Pulse */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
        <div className="cd kpi">
          <div className="kpi-label">Captures</div>
          <div className="kpi-value">{counts.total}</div>
        </div>
        <div className="cd kpi">
          <div className="kpi-label">Auto-processed</div>
          <div className="kpi-value" style={{ color: "var(--gc)" }}>{counts.processed}</div>
        </div>
        <div className="cd kpi">
          <div className="kpi-label">Need your OK</div>
          <div className="kpi-value" style={{ color: "var(--oc)" }}>{counts.needsOk}</div>
        </div>
        <div className="cd kpi">
          <div className="kpi-label">Actions created</div>
          <div className="kpi-value">{counts.actions}</div>
        </div>
      </div>

      {/* Simulator */}
      <section className="cd" style={{ padding: 16 }}>
        <div className="section-label" style={{ marginBottom: 10 }}>Try a capture (mock)</div>
        <p style={{ fontSize: 12, color: "var(--t3)", marginBottom: 10 }}>
          Run a sample voice message through the pipeline. Same flow as the real Telegram → Whisper → Claude path.
        </p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {SIMULATOR_TEMPLATES.map((tpl, idx) => (
            <button
              key={idx}
              className="btn btn-sm"
              onClick={() => runSimulation(idx)}
              disabled={!!simulating}
              style={{ background: "var(--sf)" }}
            >
              ▶ {tpl.label}
            </button>
          ))}
        </div>
        {simulating && (
          <div
            style={{
              marginTop: 12, padding: "10px 12px",
              background: "var(--pb)", color: "var(--pc)",
              borderRadius: 8, fontSize: 12, fontWeight: 500,
              display: "flex", alignItems: "center", gap: 8,
            }}
          >
            <span className="spinner" style={{ width: 12, height: 12, color: "var(--pc)" }} />
            {simulating.step === "uploading" && "Uploading audio…"}
            {simulating.step === "transcribing" && "Whisper transcribing…"}
            {simulating.step === "extracting" && "Claude extracting actions…"}
          </div>
        )}
      </section>

      {/* Captures list */}
      <section>
        <div className="section-label" style={{ marginBottom: 10 }}>Recent captures</div>
        <div className="cd" style={{ overflow: "hidden" }}>
          {captures.map((c, idx) => (
            <CaptureRow
              key={c.id}
              capture={c}
              isLast={idx === captures.length - 1}
              expanded={expanded === c.id}
              onToggle={() => setExpanded(expanded === c.id ? null : c.id)}
              onOpenContact={(id) => router.push(`/dashboard/contacts/${id}`)}
            />
          ))}
        </div>
      </section>
    </div>
  );
}

function CaptureRow({
  capture, isLast, expanded, onToggle, onOpenContact,
}: {
  capture: VoiceCapture;
  isLast: boolean;
  expanded: boolean;
  onToggle: () => void;
  onOpenContact: (id: string) => void;
}) {
  const status = STATUS_META[capture.status];
  const wave = useMemo(() => fakeWave(capture.id.length * 7), [capture.id]);

  const primaryContact =
    capture.actions.find((a) => a.contactId)?.contactName ?? null;

  return (
    <div style={{ borderBottom: isLast ? "none" : "1px solid var(--bd)" }}>
      <button
        onClick={onToggle}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          gap: 14,
          padding: "14px 16px",
          background: "transparent",
          border: "none",
          cursor: "pointer",
          textAlign: "left",
        }}
        onMouseEnter={(e) => (e.currentTarget.style.background = "var(--sf2)")}
        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
      >
        {/* Mini waveform */}
        <div style={{ display: "flex", alignItems: "center", gap: 2, width: 80, height: 28, flexShrink: 0 }}>
          {wave.slice(0, 18).map((h, i) => (
            <div
              key={i}
              style={{
                width: 2,
                height: `${h * 100}%`,
                background: capture.status === "failed" ? "var(--rc)" : "var(--bc)",
                opacity: 0.55,
                borderRadius: 1,
              }}
            />
          ))}
        </div>

        {/* Initials avatar */}
        <div
          style={{
            width: 32, height: 32, borderRadius: "50%",
            background: "var(--al)", color: "var(--t2)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 11, fontWeight: 700, flexShrink: 0,
          }}
        >
          {initials(primaryContact)}
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            {primaryContact ? (
              <span style={{ fontSize: 13, fontWeight: 600, color: "var(--t1)" }}>{primaryContact}</span>
            ) : (
              <span style={{ fontSize: 13, fontWeight: 500, color: "var(--t3)" }}>No contact detected</span>
            )}
            <span
              style={{
                display: "inline-flex", alignItems: "center", gap: 5,
                padding: "2px 8px", borderRadius: 999,
                background: status.bg, color: status.color,
                fontSize: 10, fontWeight: 600,
              }}
            >
              {status.label}
            </span>
            <span style={{ fontSize: 11, color: "var(--t3)" }}>
              · {capture.durationSec}s · {fmtAgo(capture.receivedAt)}
            </span>
          </div>
          <div
            style={{
              fontSize: 12, color: "var(--t2)", marginTop: 3,
              overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
              fontStyle: capture.status === "failed" ? "italic" : "normal",
            }}
          >
            “{capture.transcript}”
          </div>
        </div>

        {/* Action count pill */}
        <span
          style={{
            display: "inline-flex", alignItems: "center", gap: 4,
            padding: "3px 8px", borderRadius: 999,
            background: capture.actions.length === 0 ? "var(--al)" : "var(--pb)",
            color: capture.actions.length === 0 ? "var(--t3)" : "var(--pc)",
            fontSize: 10, fontWeight: 600, flexShrink: 0,
          }}
        >
          {capture.actions.length} action{capture.actions.length === 1 ? "" : "s"}
        </span>

        <span style={{ fontSize: 11, color: "var(--t3)" }}>{expanded ? "▾" : "▸"}</span>
      </button>

      {expanded && (
        <div style={{ padding: "0 16px 16px 110px" }}>
          {/* Full transcript */}
          <div
            style={{
              padding: "10px 12px",
              background: "var(--sf2)",
              border: "1px solid var(--bd)",
              borderRadius: 8,
              fontSize: 13, color: "var(--t1)", lineHeight: 1.5,
              marginBottom: 10,
            }}
          >
            {capture.transcript}
            <div className="mono" style={{ fontSize: 10, color: "var(--t3)", marginTop: 6 }}>
              Transcribed in {capture.processingMs}ms · Whisper + Claude
            </div>
          </div>

          {/* Extracted actions */}
          {capture.actions.length > 0 && (
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {capture.actions.map((a, i) => (
                <ActionRow key={i} action={a} onOpenContact={onOpenContact} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ActionRow({
  action, onOpenContact,
}: {
  action: ExtractedAction;
  onOpenContact: (id: string) => void;
}) {
  const meta = ACTION_META[action.kind];
  return (
    <div
      style={{
        display: "flex", alignItems: "center", gap: 10,
        padding: "8px 12px",
        background: "var(--sf)",
        border: "1px solid var(--bd)",
        borderLeft: `3px solid ${meta.color}`,
        borderRadius: 8,
      }}
    >
      <div
        style={{
          width: 22, height: 22, borderRadius: 6,
          background: meta.bg, color: meta.color,
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0,
        }}
      >
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d={meta.icon} />
        </svg>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 11, fontWeight: 600, color: meta.color, textTransform: "uppercase", letterSpacing: 0.04 }}>
            {meta.label}
          </span>
          {action.dueDate && (
            <span className="mono" style={{ fontSize: 10, color: "var(--t3)" }}>
              · {fmtDue(action.dueDate)}
            </span>
          )}
          {action.newStrength && (
            <span style={{ fontSize: 10, fontWeight: 600, color: "var(--rc)" }}>
              → {action.newStrength}
            </span>
          )}
        </div>
        <div style={{ fontSize: 12, color: "var(--t1)", marginTop: 1 }}>{action.description}</div>
      </div>
      {action.contactId && (
        <button
          onClick={() => onOpenContact(action.contactId!)}
          style={{
            background: "none", border: "none", color: "var(--bc)",
            fontSize: 11, cursor: "pointer", padding: "4px 8px",
            whiteSpace: "nowrap",
          }}
        >
          Open contact →
        </button>
      )}
    </div>
  );
}
