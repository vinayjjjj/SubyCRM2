"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { MOCK_INBOX, type InboxMessage } from "@/lib/mock-inbox";
import { PlatformIcon } from "@/components/platform-icon";
import type { PlatformType } from "@/lib/types";

type Filter = "all" | "unread" | "needs_reply" | "starred";

const FILTERS: { value: Filter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "unread", label: "Unread" },
  { value: "needs_reply", label: "Needs reply" },
  { value: "starred", label: "Starred" },
];

function fmtAgo(iso: string): string {
  const m = (Date.now() - new Date(iso).getTime()) / 60000;
  if (m < 1) return "now";
  if (m < 60) return `${Math.round(m)}m`;
  if (m < 60 * 24) return `${Math.round(m / 60)}h`;
  return `${Math.round(m / 60 / 24)}d`;
}

function initials(name: string): string {
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || "").join("");
}

export function InboxView() {
  const router = useRouter();
  const [messages, setMessages] = useState<InboxMessage[]>(MOCK_INBOX);
  const [filter, setFilter] = useState<Filter>("unread");
  const [selectedId, setSelectedId] = useState<string | null>(messages[0]?.id ?? null);
  const [reply, setReply] = useState("");
  const [sent, setSent] = useState(false);

  const filtered = useMemo(() => {
    return messages
      .filter((m) => {
        if (filter === "unread") return !m.read;
        if (filter === "needs_reply") return m.needsReply;
        if (filter === "starred") return m.starred;
        return true;
      })
      .sort((a, b) => +new Date(b.receivedAt) - +new Date(a.receivedAt));
  }, [messages, filter]);

  const selected = messages.find((m) => m.id === selectedId) || filtered[0] || null;

  const counts = useMemo(() => ({
    all: messages.length,
    unread: messages.filter((m) => !m.read).length,
    needs_reply: messages.filter((m) => m.needsReply).length,
    starred: messages.filter((m) => m.starred).length,
  }), [messages]);

  const markRead = (id: string) => {
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, read: true } : m)));
  };
  const toggleStar = (id: string) => {
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, starred: !m.starred } : m)));
  };
  const handleSend = () => {
    if (!reply.trim() || !selected) return;
    setSent(true);
    setMessages((prev) => prev.map((m) => (m.id === selected.id ? { ...m, needsReply: false } : m)));
    setTimeout(() => { setReply(""); setSent(false); }, 1200);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, height: "calc(100vh - 80px)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 className="page-title">Inbox</h1>
          <p style={{ color: "var(--t2)", fontSize: 13, marginTop: 4 }}>
            {counts.unread} unread · {counts.needs_reply} need reply
          </p>
        </div>
        <div className="tabs" style={{ margin: 0 }}>
          {FILTERS.map((f) => (
            <button
              key={f.value}
              className={`tab ${filter === f.value ? "active" : ""}`}
              onClick={() => setFilter(f.value)}
            >
              {f.label}
              <span style={{ marginLeft: 4, color: "var(--t3)", fontVariantNumeric: "tabular-nums" }}>
                {counts[f.value]}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="inbox-layout">
        {/* List */}
        <div className="cd inbox-list">
          {filtered.length === 0 ? (
            <div className="empty" style={{ padding: 32, fontSize: 13 }}>Nothing here.</div>
          ) : (
            filtered.map((m) => {
              const isActive = selected?.id === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => { setSelectedId(m.id); markRead(m.id); setReply(""); setSent(false); }}
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "flex-start",
                    gap: 10,
                    padding: "12px 14px",
                    background: isActive ? "var(--al)" : !m.read ? "rgba(37,99,235,0.04)" : "var(--sf)",
                    border: "none",
                    borderLeft: isActive ? "2px solid var(--ac)" : !m.read ? "2px solid var(--bc)" : "2px solid transparent",
                    borderBottom: "1px solid var(--bd)",
                    cursor: "pointer",
                    textAlign: "left",
                  }}
                >
                  <div
                    style={{
                      width: 28, height: 28, borderRadius: "50%",
                      background: "var(--sf)", color: "var(--t2)",
                      border: "1px solid var(--bd)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 10, fontWeight: 700, flexShrink: 0,
                    }}
                  >
                    {initials(m.contactName)}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <PlatformIcon type={m.platform as PlatformType} size={11} />
                      <span style={{ fontSize: 12, fontWeight: m.read ? 500 : 700, color: "var(--t1)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {m.contactName}
                      </span>
                      <span className="mono" style={{ fontSize: 10, color: "var(--t3)", marginLeft: "auto" }}>
                        {fmtAgo(m.receivedAt)}
                      </span>
                    </div>
                    <div style={{
                      fontSize: 11, color: m.read ? "var(--t3)" : "var(--t2)",
                      marginTop: 2,
                      overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                    }}>
                      {m.preview}
                    </div>
                    {m.needsReply && (
                      <span style={{
                        display: "inline-block",
                        marginTop: 4,
                        fontSize: 9, fontWeight: 600,
                        padding: "1px 6px", borderRadius: 4,
                        background: "var(--ob)", color: "var(--oc)",
                      }}>
                        NEEDS REPLY
                      </span>
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Detail + reply */}
        <div className="cd inbox-detail">
          {!selected ? (
            <div className="empty" style={{ padding: 60 }}>Select a message.</div>
          ) : (
            <>
              <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--bd)", display: "flex", alignItems: "flex-start", gap: 12 }}>
                <div
                  style={{
                    width: 36, height: 36, borderRadius: "50%",
                    background: "var(--al)", color: "var(--t2)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 12, fontWeight: 700, flexShrink: 0,
                  }}
                >
                  {initials(selected.contactName)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: "var(--t1)" }}>{selected.contactName}</div>
                  <div style={{ fontSize: 11, color: "var(--t3)", marginTop: 2, display: "flex", alignItems: "center", gap: 6 }}>
                    via <PlatformIcon type={selected.platform as PlatformType} size={11} /> {selected.platform} · {fmtAgo(selected.receivedAt)} ago
                  </div>
                </div>
                <button
                  onClick={() => toggleStar(selected.id)}
                  aria-label="Star"
                  style={{
                    background: "none", border: "none", cursor: "pointer",
                    color: selected.starred ? "var(--yc)" : "var(--t3)", fontSize: 18,
                  }}
                >
                  ★
                </button>
                <button
                  onClick={() => router.push(`/dashboard/contacts/${selected.contactId}`)}
                  className="btn btn-sm"
                >
                  Open contact
                </button>
              </div>

              <div style={{ padding: "16px 20px", flex: 1, overflowY: "auto", fontSize: 13, color: "var(--t1)", lineHeight: 1.6, whiteSpace: "pre-wrap" }}>
                {selected.body}
              </div>

              <div style={{ padding: "12px 16px", borderTop: "1px solid var(--bd)", background: "var(--sf2)" }}>
                <textarea
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  placeholder={`Reply on ${selected.platform}…`}
                  rows={3}
                  style={{ width: "100%", resize: "vertical" }}
                />
                <div style={{ display: "flex", gap: 8, marginTop: 8, alignItems: "center" }}>
                  <button className="btn btn-sm">
                    ✨ Draft with AI
                  </button>
                  <div style={{ flex: 1 }} />
                  <span style={{ fontSize: 11, color: "var(--t3)" }}>
                    Will log to {selected.contactName}&apos;s timeline
                  </span>
                  <button
                    className="btn btn-dark btn-sm"
                    onClick={handleSend}
                    disabled={!reply.trim() || sent}
                  >
                    {sent ? "Sent ✓" : "Send"}
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <style jsx>{`
        .inbox-layout {
          display: grid;
          grid-template-columns: 340px 1fr;
          gap: 16px;
          flex: 1;
          min-height: 0;
        }
        .inbox-list {
          display: flex;
          flex-direction: column;
          overflow-y: auto;
          padding: 0;
        }
        .inbox-detail {
          display: flex;
          flex-direction: column;
          overflow: hidden;
          padding: 0;
        }
        @media (max-width: 900px) {
          .inbox-layout { grid-template-columns: 1fr; }
          .inbox-list { max-height: 320px; }
        }
      `}</style>
    </div>
  );
}
