"use client";

import { useState, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { companiesApi } from "@/lib/api";
import { MOCK_COMPANIES } from "@/lib/mock-companies";
import type { Company, Contact } from "@/lib/types";

const CATEGORIES = ["all", "payment", "crypto", "vc", "partner"] as const;
type CategoryFilter = (typeof CATEGORIES)[number];

const CATEGORY_LABELS: Record<CategoryFilter, string> = {
  all: "All",
  payment: "Payment",
  crypto: "Crypto",
  vc: "VC",
  partner: "Partner",
};

const TYPE_COLORS: Record<string, string> = {
  vc: "bdg-p", lead: "bdg-b", partner: "bdg-g", friend: "bdg-y", prospect: "bdg-o",
  team: "bdg-b", advisor: "bdg-p", media: "bdg-o", other: "bdg-b",
};

function favicon(domain: string | null): string | null {
  if (!domain) return null;
  const clean = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  return `https://www.google.com/s2/favicons?sz=64&domain=${clean}`;
}

function initials(name: string): string {
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || "").join("");
}

function relativeDate(dateStr: string | null): string {
  if (!dateStr) return "Never";
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return "Today";
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days}d ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  if (days < 365) return `${Math.floor(days / 30)}mo ago`;
  return `${Math.floor(days / 365)}y ago`;
}

export function CompaniesView() {
  const router = useRouter();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("all");

  useEffect(() => {
    companiesApi.getAll()
      .then((data) => setCompanies(data?.length ? data : MOCK_COMPANIES))
      .catch(() => setCompanies(MOCK_COMPANIES))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return companies.filter((c) => {
      if (categoryFilter !== "all" && c.sector !== categoryFilter) return false;
      if (!q) return true;
      const haystack = [
        c.name, c.sector, c.size, c.funding,
        c.description, c.website, c.linkedin, c.domain,
      ].filter(Boolean).join(" ").toLowerCase();
      return q.split(/\s+/).every((token) => haystack.includes(token));
    });
  }, [companies, query, categoryFilter]);

  useEffect(() => {
    if (!selectedId && filtered.length > 0) setSelectedId(filtered[0].id);
    if (selectedId && !filtered.find((c) => c.id === selectedId) && filtered.length > 0) {
      setSelectedId(filtered[0].id);
    }
  }, [filtered, selectedId]);

  const selected = companies.find((c) => c.id === selectedId) || null;

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 80 }}>
        <span className="spinner" style={{ width: 20, height: 20, color: "var(--t3)" }} />
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, height: "calc(100vh - 100px)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 className="page-title">Companies</h1>
          <p style={{ color: "var(--t2)", fontSize: 13, marginTop: 4 }}>
            {filtered.length} of {companies.length} compan{companies.length === 1 ? "y" : "ies"}
          </p>
        </div>
      </div>

      <div className="split-layout">
        {/* Left pane: list */}
        <div className="cd split-list">
          <div style={{ padding: 12, borderBottom: "1px solid var(--bd)", display: "flex", flexDirection: "column", gap: 10 }}>
            <input
              placeholder="Search name, sector, funding..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <div className="tabs" style={{ margin: 0 }}>
              {CATEGORIES.map((s) => {
                const count = s === "all"
                  ? companies.length
                  : companies.filter((c) => c.sector === s).length;
                return (
                  <button
                    key={s}
                    className={`tab ${categoryFilter === s ? "active" : ""}`}
                    onClick={() => setCategoryFilter(s)}
                    style={{ flex: 1, padding: "5px 6px", fontSize: 12 }}
                  >
                    {CATEGORY_LABELS[s]}
                    <span style={{ marginLeft: 4, color: "var(--t3)", fontVariantNumeric: "tabular-nums" }}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
          <div style={{ overflowY: "auto", flex: 1 }}>
            {filtered.length === 0 ? (
              <div className="empty" style={{ padding: 32 }}>No companies match.</div>
            ) : (
              filtered.map((c) => {
                const isActive = c.id === selectedId;
                const icon = favicon(c.domain || c.website);
                return (
                  <button
                    key={c.id}
                    onClick={() => setSelectedId(c.id)}
                    className="company-row"
                    style={{
                      width: "100%",
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                      padding: "10px 14px",
                      border: "none",
                      background: isActive ? "var(--al)" : "transparent",
                      borderLeft: isActive ? "2px solid var(--ac)" : "2px solid transparent",
                      cursor: "pointer",
                      textAlign: "left",
                      borderBottom: "1px solid var(--bd)",
                      transition: "background 0.1s",
                    }}
                  >
                    <div
                      style={{
                        width: 28, height: 28, borderRadius: 6,
                        background: "var(--sf2)", border: "1px solid var(--bd)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        overflow: "hidden", flexShrink: 0,
                      }}
                    >
                      {icon ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={icon} alt="" width={20} height={20} style={{ borderRadius: 3 }} />
                      ) : (
                        <span style={{ fontSize: 11, fontWeight: 600, color: "var(--t2)" }}>{initials(c.name)}</span>
                      )}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 500, color: "var(--t1)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {c.name}
                      </div>
                      <div style={{ fontSize: 11, color: "var(--t3)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", marginTop: 1 }}>
                        {[c.sector, c.size].filter(Boolean).join(" · ") || "·"}
                      </div>
                    </div>
                    <span style={{ fontSize: 11, color: "var(--t2)", fontVariantNumeric: "tabular-nums", flexShrink: 0 }}>
                      {c.contactCount ?? 0}
                    </span>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right pane: detail */}
        <div className="cd split-detail">
          {selected ? (
            <CompanyDetailPanel company={selected} onOpenContact={(id) => router.push(`/dashboard/contacts/${id}`)} />
          ) : (
            <div className="empty" style={{ padding: 60 }}>Select a company on the left.</div>
          )}
        </div>
      </div>

      <style jsx>{`
        .split-layout {
          display: grid;
          grid-template-columns: 320px 1fr;
          gap: 16px;
          flex: 1;
          min-height: 0;
        }
        .split-list {
          display: flex;
          flex-direction: column;
          overflow: hidden;
          padding: 0;
        }
        .split-detail {
          overflow-y: auto;
          padding: 24px 28px;
        }
        .company-row:hover {
          background: var(--sf2) !important;
        }
        @media (max-width: 900px) {
          .split-layout {
            grid-template-columns: 1fr;
          }
          .split-list {
            max-height: 320px;
          }
        }
      `}</style>
    </div>
  );
}

function CompanyDetailPanel({ company, onOpenContact }: { company: Company; onOpenContact: (id: string) => void }) {
  const icon = favicon(company.domain || company.website);
  const contacts = company.contacts || [];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div
          style={{
            width: 56, height: 56, borderRadius: 12,
            background: "var(--sf2)", border: "1px solid var(--bd)",
            display: "flex", alignItems: "center", justifyContent: "center",
            overflow: "hidden", flexShrink: 0,
          }}
        >
          {icon ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={icon} alt="" width={36} height={36} style={{ borderRadius: 6 }} />
          ) : (
            <span style={{ fontSize: 18, fontWeight: 700, color: "var(--t2)" }}>{initials(company.name)}</span>
          )}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 style={{ fontSize: 22, fontWeight: 700, letterSpacing: "-0.02em", color: "var(--t1)" }}>
            {company.name}
          </h2>
          <div style={{ display: "flex", gap: 6, marginTop: 6, flexWrap: "wrap" }}>
            {company.sector && <span className="bdg bdg-p">{company.sector}</span>}
            {company.size && <span className="bdg bdg-g">{company.size}</span>}
            {company.funding && <span className="bdg bdg-o">{company.funding}</span>}
          </div>
        </div>
      </div>

      {company.description && (
        <p style={{ fontSize: 14, color: "var(--t2)", lineHeight: 1.6 }}>{company.description}</p>
      )}

      {/* Links */}
      {(company.website || company.linkedin) && (
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {company.website && (
            <a
              href={company.website.startsWith("http") ? company.website : `https://${company.website}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-sm"
              style={{ textDecoration: "none" }}
            >
              Website ↗
            </a>
          )}
          {company.linkedin && (
            <a
              href={company.linkedin.startsWith("http") ? company.linkedin : `https://${company.linkedin}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-sm"
              style={{ textDecoration: "none" }}
            >
              LinkedIn ↗
            </a>
          )}
        </div>
      )}

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
        <div className="cd kpi">
          <div className="kpi-label">Contacts</div>
          <div className="kpi-value">{contacts.length || (company.contactCount ?? 0)}</div>
        </div>
        <div className="cd kpi">
          <div className="kpi-label">Hot</div>
          <div className="kpi-value">{contacts.filter((c) => c.relationshipStrength === "hot").length}</div>
        </div>
        <div className="cd kpi">
          <div className="kpi-label">Warm</div>
          <div className="kpi-value">{contacts.filter((c) => c.relationshipStrength === "warm").length}</div>
        </div>
      </div>

      {/* Contacts */}
      <div>
        <div className="section-label" style={{ marginBottom: 10 }}>
          Contacts ({contacts.length})
        </div>
        {contacts.length === 0 ? (
          <div className="empty" style={{ padding: 24, fontSize: 13 }}>No contacts linked yet.</div>
        ) : (
          <div className="cd" style={{ overflow: "hidden" }}>
            {contacts.map((c: Contact, idx) => (
              <button
                key={c.id}
                onClick={() => onOpenContact(c.id)}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "12px 16px",
                  border: "none",
                  borderBottom: idx < contacts.length - 1 ? "1px solid var(--bd)" : "none",
                  background: "transparent",
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "background 0.1s",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--sf2)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
              >
                <div
                  style={{
                    width: 32, height: 32, borderRadius: "50%",
                    background: "var(--al)", color: "var(--t2)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 12, fontWeight: 600, flexShrink: 0,
                  }}
                >
                  {initials(c.name)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: "var(--t1)" }}>{c.name}</div>
                  <div style={{ fontSize: 12, color: "var(--t3)", marginTop: 1 }}>{c.role || "·"}</div>
                </div>
                <span className={`bdg ${TYPE_COLORS[c.type] || "bdg-b"}`}>{c.type}</span>
                <span className="mono" style={{ color: "var(--t3)", fontSize: 11, minWidth: 64, textAlign: "right" }}>
                  {relativeDate(c.lastContactDate)}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
