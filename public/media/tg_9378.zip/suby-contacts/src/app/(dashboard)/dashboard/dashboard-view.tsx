"use client";

import { useState, useEffect, useMemo } from "react";
import { remindersApi } from "@/lib/api";
import { MOCK_REMINDERS } from "@/lib/mock-reminders";
import { MOCK_EVENTS, type CalendarEvent, type CallChannel } from "@/lib/mock-events";
import { MOCK_CONTACTS } from "@/lib/mock-contacts";
import { computeSuggestions, URGENCY_COLOR, type ReachOutSuggestion } from "@/lib/mock-suggestions";
import { PlatformIcon } from "@/components/platform-icon";
import type { Reminder, Contact, PlatformType } from "@/lib/types";

const CHANNEL_META: Record<CallChannel, { label: string; icon: string; color: string; bg: string }> = {
  zoom: { label: "Zoom", icon: "🎥", color: "#2D8CFF", bg: "#2D8CFF15" },
  meet: { label: "Meet", icon: "📹", color: "#34A853", bg: "#34A85315" },
  phone: { label: "Phone", icon: "📞", color: "var(--gc)", bg: "var(--gb)" },
  in_person: { label: "In person", icon: "🤝", color: "var(--oc)", bg: "var(--ob)" },
  telegram: { label: "Telegram", icon: "✈️", color: "#229ED9", bg: "#229ED915" },
  x_space: { label: "X Space", icon: "🎙️", color: "var(--t1)", bg: "var(--al)" },
};

const CONTACT_LOOKUP: Record<string, Contact> = Object.fromEntries(
  MOCK_CONTACTS.map((c) => [c.id, c]),
);

function fmtTime(d: Date): string {
  return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
}

function initials(name: string): string {
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || "").join("");
}

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function isThisWeek(d: Date): boolean {
  const now = new Date();
  const start = startOfDay(now);
  const dow = (start.getDay() + 6) % 7;
  start.setDate(start.getDate() - dow);
  const end = new Date(start);
  end.setDate(end.getDate() + 7);
  return d >= start && d < end;
}

function BriefIcon({ path, color, size = 13 }: { path: string; color: string; size?: number }) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24"
      fill="none" stroke={color} strokeWidth={2}
      strokeLinecap="round" strokeLinejoin="round"
      style={{ flexShrink: 0, verticalAlign: "-2px" }}
      aria-hidden
    >
      <path d={path} />
    </svg>
  );
}

function greeting(): string {
  const h = new Date().getHours();
  if (h < 6) return "Late night";
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

export function DashboardView() {
  const [overdueReminders, setOverdueReminders] = useState<Reminder[]>([]);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  useEffect(() => {
    const overdueMock = MOCK_REMINDERS.filter(
      (r) => r.status === "pending" && new Date(r.dueDate).getTime() < Date.now(),
    );
    remindersApi.getDue()
      .then((r) => setOverdueReminders(r?.length ? r : overdueMock))
      .catch(() => setOverdueReminders(overdueMock));
  }, []);

  const todayEvents = useMemo(() => {
    const today = new Date().toDateString();
    return MOCK_EVENTS
      .filter((e) => new Date(e.start).toDateString() === today)
      .sort((a, b) => +new Date(a.start) - +new Date(b.start));
  }, []);

  // Past events from last 3 days, sorted most recent first
  const pendingOutcomeEvents = useMemo(() => {
    const now = Date.now();
    return MOCK_EVENTS
      .filter((e) => {
        const end = new Date(e.end).getTime();
        return end < now && (now - end) < 3 * 86400000;
      })
      .sort((a, b) => +new Date(b.start) - +new Date(a.start));
  }, []);
  const [outcomes, setOutcomes] = useState<Record<string, "strong" | "ok" | "cold" | "noshow" | "dismissed">>({});

  const suggestions = useMemo(
    () => computeSuggestions(20).filter((s) => !dismissed.has(s.contactId)).slice(0, 4),
    [dismissed],
  );
  const [expandedDraft, setExpandedDraft] = useState<string | null>(null);

  const weeklyPulse = useMemo(() => {
    const weekEvents = MOCK_EVENTS.filter((e) => isThisWeek(new Date(e.start)));
    const newContactsThisWeek = MOCK_CONTACTS.filter((c) => isThisWeek(new Date(c.createdAt))).length;
    const hotCount = MOCK_CONTACTS.filter((c) => c.relationshipStrength === "hot").length;
    return {
      calls: weekEvents.length,
      newContacts: newContactsThisWeek,
      hot: hotCount,
    };
  }, []);

  const markReminderDone = (id: string) => {
    setOverdueReminders((prev) => prev.filter((r) => r.id !== id));
    remindersApi.update(id, { status: "done" }).catch(() => {});
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 28, maxWidth: 980 }}>
      {/* Greeting */}
      <div>
        <h1 className="page-title">{greeting()}, Gaspard</h1>
        <p style={{ color: "var(--t2)", fontSize: 14, marginTop: 4 }}>
          {[
            todayEvents.length > 0 ? `${todayEvents.length} call${todayEvents.length > 1 ? "s" : ""} today` : null,
            overdueReminders.length > 0 ? `${overdueReminders.length} overdue` : null,
            suggestions.length > 0 ? `${suggestions.length} reach-out${suggestions.length > 1 ? "s" : ""} to do` : null,
          ].filter(Boolean).join(" · ") || "All caught up."}
        </p>
      </div>

      {/* Daily morning brief — preview of what @subyassist_bot pushes at 8am */}
      <DailyBriefCard
        todayEvents={todayEvents}
        overdueCount={overdueReminders.length}
        topSuggestion={suggestions[0] ?? null}
      />

      {/* Weekly pulse */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        <div className="cd kpi">
          <div className="kpi-label">Calls this week</div>
          <div className="kpi-value">{weeklyPulse.calls}</div>
        </div>
        <div className="cd kpi">
          <div className="kpi-label">Hot contacts</div>
          <div className="kpi-value" style={{ color: "var(--rc)" }}>{weeklyPulse.hot}</div>
        </div>
        <div className="cd kpi">
          <div className="kpi-label">New this week</div>
          <div className="kpi-value">{weeklyPulse.newContacts}</div>
        </div>
      </div>

      {/* Past calls awaiting outcome */}
      {pendingOutcomeEvents.filter((e) => !outcomes[e.id]).length > 0 && (
        <section>
          <SectionHead title="How did it go?" count={pendingOutcomeEvents.filter((e) => !outcomes[e.id]).length} tone="var(--bc)" />
          <div className="cd" style={{ overflow: "hidden" }}>
            {pendingOutcomeEvents
              .filter((e) => !outcomes[e.id])
              .slice(0, 4)
              .map((e, idx, arr) => (
                <OutcomeRow
                  key={e.id}
                  event={e}
                  isLast={idx === arr.length - 1}
                  onPick={(outcome) => setOutcomes((prev) => ({ ...prev, [e.id]: outcome }))}
                />
              ))}
          </div>
        </section>
      )}

      {/* Today's calls */}
      <section>
        <SectionHead title="Today's calls" count={todayEvents.length} />
        {todayEvents.length === 0 ? (
          <div className="cd" style={{ padding: 28, textAlign: "center" }}>
            <div className="empty" style={{ padding: 0, fontSize: 13 }}>No calls scheduled today.</div>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {todayEvents.map((e) => <TodayCallRow key={e.id} event={e} />)}
          </div>
        )}
      </section>

      {/* Overdue reminders */}
      {overdueReminders.length > 0 && (
        <section>
          <SectionHead title="Overdue reminders" count={overdueReminders.length} tone="var(--rc)" />
          <div className="cd" style={{ overflow: "hidden" }}>
            {overdueReminders.map((r, idx) => (
              <div
                key={r.id}
                style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "12px 16px",
                  borderBottom: idx < overdueReminders.length - 1 ? "1px solid var(--bd)" : "none",
                }}
              >
                <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--rc)", flexShrink: 0 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: "var(--t1)" }}>{r.content}</div>
                  <div style={{ fontSize: 11, color: "var(--rc)", marginTop: 2 }}>
                    {r.contact?.name} · Due {new Date(r.dueDate).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                  </div>
                </div>
                <button className="btn btn-sm" onClick={() => markReminderDone(r.id)}>Done</button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* AI proactive reach-out — top suggestions */}
      <section>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <h2 style={{ fontSize: 15, fontWeight: 700, color: "var(--t1)" }}>Reach-outs to do</h2>
          <span className="bdg bdg-p" style={{ fontSize: 10 }}>AI</span>
          <span style={{ fontSize: 11, color: "var(--t3)", fontVariantNumeric: "tabular-nums" }}>
            {suggestions.length}
          </span>
        </div>

        {suggestions.length === 0 ? (
          <div className="cd" style={{ padding: 32, textAlign: "center" }}>
            <div className="empty" style={{ padding: 0, fontSize: 13 }}>
              You&apos;re all caught up. No priority reach-outs.
            </div>
          </div>
        ) : (
          <div className="cd" style={{ overflow: "hidden" }}>
            {suggestions.map((s, idx) => (
              <ReachOutRow
                key={s.contactId}
                suggestion={s}
                last={idx === suggestions.length - 1}
                expanded={expandedDraft === s.contactId}
                onToggle={() => setExpandedDraft(expandedDraft === s.contactId ? null : s.contactId)}
                onSkip={() => setDismissed((prev) => new Set(prev).add(s.contactId))}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function SectionHead({ title, count, tone }: { title: string; count: number; tone?: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
      <h2 style={{ fontSize: 15, fontWeight: 700, color: tone || "var(--t1)" }}>{title}</h2>
      <span style={{ fontSize: 11, color: "var(--t3)", fontVariantNumeric: "tabular-nums" }}>{count}</span>
    </div>
  );
}

function TodayCallRow({ event }: { event: CalendarEvent }) {
  const start = new Date(event.start);
  const end = new Date(event.end);
  const meta = CHANNEL_META[event.channel];
  const isLink = event.location && /^https?:\/\//.test(event.location);
  return (
    <a
      href={isLink ? event.location : "/dashboard/prep"}
      target={isLink ? "_blank" : undefined}
      rel={isLink ? "noopener noreferrer" : undefined}
      style={{
        display: "flex", alignItems: "center", gap: 14, padding: "12px 14px",
        background: "var(--sf)", border: "1px solid var(--bd)", borderLeft: `3px solid ${meta.color}`,
        borderRadius: "var(--r)", textDecoration: "none",
        transition: "box-shadow 0.12s, transform 0.12s",
      }}
      className="today-row"
    >
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", minWidth: 56 }}>
        <span className="mono" style={{ fontSize: 14, fontWeight: 600, color: "var(--t1)" }}>{fmtTime(start)}</span>
        <span className="mono" style={{ fontSize: 10, color: "var(--t3)" }}>{fmtTime(end)}</span>
      </div>
      <div style={{ width: 1, alignSelf: "stretch", background: "var(--bd)" }} />
      <div
        style={{
          width: 36, height: 36, borderRadius: "50%",
          background: "var(--al)", color: "var(--t2)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 12, fontWeight: 700, flexShrink: 0,
        }}
      >
        {initials(event.contactName)}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: "var(--t1)" }}>{event.contactName}</div>
        <div style={{ fontSize: 12, color: "var(--t2)", marginTop: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {event.title}
        </div>
      </div>
      <span
        style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "4px 10px", borderRadius: 999,
          background: meta.bg, color: meta.color,
          fontSize: 11, fontWeight: 600,
        }}
      >
        <span>{meta.icon}</span>
        {meta.label}
      </span>
      <span style={{ fontSize: 13, color: "var(--t3)" }}>→</span>
      <style jsx>{`
        .today-row:hover {
          box-shadow: var(--shadow);
          transform: translateY(-1px);
        }
      `}</style>
    </a>
  );
}

function ReachOutRow({
  suggestion, last, expanded, onToggle, onSkip,
}: {
  suggestion: ReachOutSuggestion;
  last: boolean;
  expanded: boolean;
  onToggle: () => void;
  onSkip: () => void;
}) {
  const u = URGENCY_COLOR[suggestion.urgency];
  const [copied, setCopied] = useState(false);
  const c = suggestion.contact;

  const copy = () => {
    navigator.clipboard?.writeText(suggestion.draftMessage).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }).catch(() => {});
  };

  return (
    <div style={{ borderBottom: last ? "none" : "1px solid var(--bd)" }}>
      <button
        onClick={onToggle}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "12px 14px",
          background: "transparent",
          border: "none",
          cursor: "pointer",
          textAlign: "left",
          transition: "background 0.1s",
        }}
        onMouseEnter={(e) => (e.currentTarget.style.background = "var(--sf2)")}
        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
      >
        <span style={{ width: 6, height: 6, borderRadius: "50%", background: u.color, flexShrink: 0 }} />
        <div
          style={{
            width: 32, height: 32, borderRadius: "50%",
            background: "var(--al)", color: "var(--t2)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 11, fontWeight: 700, flexShrink: 0,
          }}
        >
          {initials(c.name)}
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: "var(--t1)" }}>
            {c.name}
            {c.company && (
              <span style={{ fontWeight: 400, color: "var(--t3)", marginLeft: 6 }}>
                · {c.company}
              </span>
            )}
          </div>
          <div style={{ fontSize: 11, color: u.color, marginTop: 1, fontWeight: 500 }}>
            {suggestion.reason}
          </div>
        </div>

        {suggestion.channel && (
          <span
            title={suggestion.channel}
            style={{
              display: "inline-flex", alignItems: "center", gap: 5,
              padding: "3px 8px", borderRadius: 999,
              background: "var(--al)", border: "1px solid var(--bd)",
              fontSize: 10, flexShrink: 0,
            }}
          >
            <PlatformIcon type={suggestion.channel as PlatformType} size={11} />
            <span className="mono" style={{ fontSize: 10, color: "var(--t2)" }}>
              {suggestion.channelHandle}
            </span>
          </span>
        )}

        <span style={{ fontSize: 11, color: "var(--t3)", flexShrink: 0 }}>
          {expanded ? "▾" : "▸"}
        </span>
      </button>

      {expanded && (
        <div style={{ padding: "0 14px 14px 50px" }}>
          <div
            style={{
              padding: "12px 14px",
              background: "var(--sf2)",
              border: "1px solid var(--bd)",
              borderRadius: 8,
              fontSize: 13, lineHeight: 1.5, color: "var(--t1)",
              whiteSpace: "pre-wrap",
            }}
          >
            {suggestion.draftMessage}
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 8, alignItems: "center" }}>
            <button className="btn btn-dark btn-sm" onClick={(e) => { e.stopPropagation(); copy(); }}>
              {copied ? "Copied ✓" : "Copy"}
            </button>
            <button className="btn btn-sm" onClick={(e) => e.stopPropagation()}>Regenerate</button>
            <div style={{ flex: 1 }} />
            <button
              onClick={(e) => { e.stopPropagation(); onSkip(); }}
              style={{
                background: "none", border: "none", color: "var(--t3)",
                fontSize: 11, cursor: "pointer", padding: "4px 8px",
              }}
            >
              Skip
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function DailyBriefCard({
  todayEvents,
  overdueCount,
  topSuggestion,
}: {
  todayEvents: CalendarEvent[];
  overdueCount: number;
  topSuggestion: ReachOutSuggestion | null;
}) {
  const now = new Date();
  const dateLabel = now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
  // Fake birthday — pick a deterministic contact each day
  const birthdayContact = MOCK_CONTACTS[(now.getDate() + now.getMonth()) % MOCK_CONTACTS.length];

  return (
    <div
      className="cd"
      style={{
        padding: 0,
        overflow: "hidden",
        background: "linear-gradient(135deg, #229ED915 0%, var(--sf) 60%)",
        border: "1px solid var(--bd)",
      }}
    >
      <div
        style={{
          padding: "10px 14px",
          borderBottom: "1px solid var(--bd)",
          display: "flex",
          alignItems: "center",
          gap: 8,
          background: "var(--sf2)",
        }}
      >
        <span
          style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: 22, height: 22, borderRadius: "50%",
            background: "#229ED915",
          }}
        >
          <svg width="12" height="12" viewBox="0 0 24 24" fill="#229ED9">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.03-1.99 1.27-5.62 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.37-.49 1.02-.74 3.99-1.74 6.65-2.89 7.99-3.44 3.8-1.58 4.59-1.86 5.1-1.87.11 0 .37.03.54.17.14.12.18.28.2.45-.01.06.01.24 0 .38z" />
          </svg>
        </span>
        <span style={{ fontSize: 12, fontWeight: 600, color: "var(--t1)" }}>
          @subyassist_bot
        </span>
        <span style={{ fontSize: 11, color: "var(--t3)" }}>· Daily brief preview · 8:00</span>
        <span style={{ marginLeft: "auto", fontSize: 10, color: "var(--t3)", textTransform: "uppercase", letterSpacing: 0.04 }}>
          Telegram push
        </span>
      </div>
      <div style={{ padding: "14px 16px", fontSize: 13, color: "var(--t1)", lineHeight: 1.6 }}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>Good morning Gaspard, {dateLabel}</div>

        <div style={{ marginTop: 8 }}>
          <strong style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
            <BriefIcon path="M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z M16 2v4 M8 2v4 M3 10h18" color="#229ED9" />
            Today
          </strong>
          {todayEvents.length === 0 ? (
            <div style={{ color: "var(--t3)", fontSize: 12 }}>No calls scheduled.</div>
          ) : (
            <ul style={{ margin: "4px 0 0 18px", padding: 0 }}>
              {todayEvents.slice(0, 3).map((e) => {
                const t = new Date(e.start);
                return (
                  <li key={e.id} style={{ fontSize: 12, color: "var(--t2)" }}>
                    <span className="mono" style={{ color: "var(--t1)" }}>
                      {t.getHours().toString().padStart(2, "0")}:{t.getMinutes().toString().padStart(2, "0")}
                    </span>{" "}
                    · {e.contactName} ({e.channel.replace("_", " ")})
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {topSuggestion && (
          <div style={{ marginTop: 8 }}>
            <strong style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
              <BriefIcon path="M12 22a10 10 0 1 0-10-10 10 10 0 0 0 10 10z M12 18a6 6 0 1 0-6-6 6 6 0 0 0 6 6z M12 14a2 2 0 1 0-2-2 2 2 0 0 0 2 2z" color="var(--oc)" />
              Top reach-out today
            </strong>
            <div style={{ fontSize: 12, color: "var(--t2)", marginLeft: 22 }}>
              {topSuggestion.contact.name} · {topSuggestion.reason.toLowerCase()}
            </div>
          </div>
        )}

        {overdueCount > 0 && (
          <div style={{ marginTop: 8 }}>
            <strong style={{ color: "var(--rc)", display: "inline-flex", alignItems: "center", gap: 6 }}>
              <BriefIcon path="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z M12 9v4 M12 17h.01" color="var(--rc)" />
              {overdueCount} reminder{overdueCount > 1 ? "s" : ""} overdue
            </strong>
            <div style={{ fontSize: 12, color: "var(--t3)", marginLeft: 22 }}>
              You can clear these in 2 minutes.
            </div>
          </div>
        )}

        <div style={{ marginTop: 8 }}>
          <strong style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
            <BriefIcon path="M20 21V11a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v10 M2 21h20 M12 9V5a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2 M8 5a2 2 0 1 1 4 0v4" color="var(--pc)" />
            Anniversary
          </strong>
          <div style={{ fontSize: 12, color: "var(--t2)", marginLeft: 22 }}>
            {birthdayContact.name} is celebrating 3 years at {birthdayContact.company || "their company"}.
          </div>
        </div>

        <div style={{ marginTop: 12, paddingTop: 10, borderTop: "1px dashed var(--bd)", fontSize: 11, color: "var(--t3)" }}>
          Type <span className="mono" style={{ color: "var(--t1)" }}>/brief off</span> to stop · send a voice note to reply.
        </div>
      </div>
    </div>
  );
}

const OUTCOME_OPTIONS: { value: "strong" | "ok" | "cold" | "noshow"; label: string; bg: string; color: string; icon: string }[] = [
  { value: "strong",  label: "Strong",   bg: "var(--gb)", color: "var(--gc)", icon: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" },
  { value: "ok",      label: "OK",       bg: "var(--bb)", color: "var(--bc)", icon: "M22 11.08V12a10 10 0 1 1-5.93-9.14 M22 4L12 14.01l-3-3" },
  { value: "cold",    label: "Cold",     bg: "var(--al)", color: "var(--t2)", icon: "M12 2v20 M2 12h20 M19 5l-14 14 M5 5l14 14" },
  { value: "noshow",  label: "No-show",  bg: "var(--rb)", color: "var(--rc)", icon: "M18.36 6.64a9 9 0 1 1-12.73 0 M12 2v10" },
];

function OutcomeRow({
  event, isLast, onPick,
}: {
  event: CalendarEvent;
  isLast: boolean;
  onPick: (o: "strong" | "ok" | "cold" | "noshow" | "dismissed") => void;
}) {
  const when = new Date(event.start);
  const ago = Math.round((Date.now() - when.getTime()) / 3600000);
  const agoLabel = ago < 24 ? `${ago}h ago` : `${Math.round(ago / 24)}d ago`;

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "12px 14px",
        borderBottom: isLast ? "none" : "1px solid var(--bd)",
      }}
    >
      <div
        style={{
          width: 32, height: 32, borderRadius: "50%",
          background: "var(--al)", color: "var(--t2)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 11, fontWeight: 700, flexShrink: 0,
        }}
      >
        {initials(event.contactName)}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: "var(--t1)" }}>{event.contactName}</div>
        <div style={{ fontSize: 11, color: "var(--t3)" }}>
          {event.title} · {agoLabel}
        </div>
      </div>
      <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
        {OUTCOME_OPTIONS.map((o) => (
          <button
            key={o.value}
            onClick={() => onPick(o.value)}
            style={{
              display: "inline-flex", alignItems: "center", gap: 5,
              padding: "4px 9px",
              borderRadius: 6,
              border: "1px solid var(--bd)",
              background: o.bg,
              color: o.color,
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "transform 0.1s",
              whiteSpace: "nowrap",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-1px)")}
            onMouseLeave={(e) => (e.currentTarget.style.transform = "none")}
          >
            <BriefIcon path={o.icon} color={o.color} size={11} />
            {o.label}
          </button>
        ))}
        <button
          aria-label="Skip"
          onClick={() => onPick("dismissed")}
          style={{
            background: "none", border: "none", color: "var(--t3)",
            cursor: "pointer", padding: 4, fontSize: 12,
          }}
        >
          ×
        </button>
      </div>
    </div>
  );
}
