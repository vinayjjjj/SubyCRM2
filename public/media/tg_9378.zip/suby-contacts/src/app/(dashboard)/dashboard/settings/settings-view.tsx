"use client";

import { useState } from "react";
import Link from "next/link";

type IntegrationKey =
  | "subyassist_bot"
  | "google_calendar"
  | "gmail"
  | "beeper"
  | "telegram"
  | "discord"
  | "slack"
  | "whatsapp"
  | "linkedin"
  | "x";

type Status = "connected" | "disconnected" | "error";

interface Integration {
  key: IntegrationKey;
  name: string;
  description: string;
  color: string;
  bg: string;
  icon: string; // svg path d
  account?: string;
  meta?: string;
  status: Status;
  scopes?: string[];
}

const INITIAL: Integration[] = [
  // ─── Voice assistant ─────────────────────────────────
  {
    key: "subyassist_bot",
    name: "@subyassist_bot",
    description: "Telegram voice bot. Send voice notes → Whisper transcribes → Claude creates notes/reminders/strength bumps on the matching contacts.",
    color: "#229ED9",
    bg: "#229ED915",
    icon: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.03-1.99 1.27-5.62 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.37-.49 1.02-.74 3.99-1.74 6.65-2.89 7.99-3.44 3.8-1.58 4.59-1.86 5.1-1.87.11 0 .37.03.54.17.14.12.18.28.2.45-.01.06.01.24 0 .38z",
    account: "t.me/subyassist_bot",
    meta: "8 captures · 11 actions created · 2 pending",
    status: "connected",
  },
  // ─── Calendar ─────────────────────────────────────────
  {
    key: "google_calendar",
    name: "Google Calendar",
    description: "Sync your calendar to pre-call. Detects upcoming meetings and links them to contacts.",
    color: "#4285F4",
    bg: "#4285F415",
    icon: "M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z",
    account: "gaspard@suby.fi",
    meta: "3 calendars · synced 2 min ago",
    status: "connected",
    scopes: ["events.read", "events.write"],
  },
  // ─── Email ───────────────────────────────────────────
  {
    key: "gmail",
    name: "Gmail",
    description: "Index emails from key contacts and surface them in the contact timeline.",
    color: "#EA4335",
    bg: "#EA433515",
    icon: "M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z",
    account: "gaspard@suby.fi",
    meta: "12,438 emails indexed · last sync 5 min ago",
    status: "connected",
    scopes: ["read"],
  },
  // ─── Messaging unified ───────────────────────────────
  {
    key: "beeper",
    name: "Beeper",
    description: "Unified inbox via Matrix bridges. Pulls WhatsApp, iMessage, Signal, Instagram and more.",
    color: "#000000",
    bg: "var(--al)",
    icon: "M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5",
    status: "disconnected",
  },
  {
    key: "telegram",
    name: "Telegram",
    description: "Read DMs and groups to attribute messages to contacts automatically.",
    color: "#229ED9",
    bg: "#229ED915",
    icon: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.03-1.99 1.27-5.62 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.37-.49 1.02-.74 3.99-1.74 6.65-2.89 7.99-3.44 3.8-1.58 4.59-1.86 5.1-1.87.11 0 .37.03.54.17.14.12.18.28.2.45-.01.06.01.24 0 .38z",
    account: "@gaspard_suby",
    meta: "1 personal account",
    status: "connected",
  },
  {
    key: "discord",
    name: "Discord",
    description: "Track DMs and key server activity from the founders & devs you talk to.",
    color: "#5865F2",
    bg: "#5865F215",
    icon: "M20.317 4.37a19.791 19.791 0 00-4.885-1.515.074.074 0 00-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 00-5.487 0 12.64 12.64 0 00-.617-1.25.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 00-.041-.106 13.107 13.107 0 01-1.872-.892.077.077 0 01-.008-.128 10.2 10.2 0 00.372-.292.074.074 0 01.077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 01.078.01c.12.098.246.198.373.292a.077.077 0 01-.006.127 12.299 12.299 0 01-1.873.892.077.077 0 00-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 00.084.028 19.839 19.839 0 006.002-3.03.077.077 0 00.032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 00-.031-.03z",
    status: "disconnected",
  },
  {
    key: "slack",
    name: "Slack",
    description: "Connect workspaces to log DMs with partners and investors.",
    color: "#E01E5A",
    bg: "#E01E5A15",
    icon: "M5.042 15.165a2.528 2.528 0 01-2.52 2.523A2.528 2.528 0 010 15.165a2.527 2.527 0 012.522-2.52h2.52v2.52zm1.271 0a2.527 2.527 0 012.521-2.52 2.527 2.527 0 012.521 2.52v6.313A2.528 2.528 0 018.834 24a2.528 2.528 0 01-2.521-2.522v-6.313zM8.834 5.042a2.528 2.528 0 01-2.521-2.52A2.528 2.528 0 018.834 0a2.528 2.528 0 012.521 2.522v2.52H8.834zm0 1.271a2.528 2.528 0 012.521 2.521 2.528 2.528 0 01-2.521 2.521H2.522A2.528 2.528 0 010 8.834a2.528 2.528 0 012.522-2.521h6.312zM18.956 8.834a2.528 2.528 0 012.522-2.521A2.528 2.528 0 0124 8.834a2.528 2.528 0 01-2.522 2.521h-2.522V8.834zm-1.27 0a2.528 2.528 0 01-2.523 2.521 2.527 2.527 0 01-2.52-2.521V2.522A2.527 2.527 0 0115.163 0a2.528 2.528 0 012.523 2.522v6.312zM15.163 18.956a2.528 2.528 0 012.523 2.522A2.528 2.528 0 0115.163 24a2.527 2.527 0 01-2.52-2.522v-2.522h2.52zm0-1.27a2.527 2.527 0 01-2.52-2.523 2.527 2.527 0 012.52-2.52h6.315A2.528 2.528 0 0124 15.163a2.528 2.528 0 01-2.522 2.523h-6.315z",
    status: "disconnected",
  },
  {
    key: "whatsapp",
    name: "WhatsApp",
    description: "Available through Beeper or via a one-time chat export upload.",
    color: "#25D366",
    bg: "#25D36615",
    icon: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 2C6.478 2 2 6.478 2 12c0 1.89.525 3.66 1.438 5.168L2 22l4.832-1.438A9.93 9.93 0 0012 22c5.522 0 10-4.478 10-10S17.522 2 12 2z",
    status: "disconnected",
  },
  // ─── Social ──────────────────────────────────────────
  {
    key: "linkedin",
    name: "LinkedIn",
    description: "Match contacts to LinkedIn profiles and enrich roles automatically.",
    color: "#0A66C2",
    bg: "#0A66C215",
    icon: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z",
    account: "in/gaspard",
    meta: "Sales Nav · 240 saved leads",
    status: "connected",
  },
  {
    key: "x",
    name: "X / Twitter",
    description: "Read DMs and likes/replies from the founders & investors you follow.",
    color: "#000000",
    bg: "var(--al)",
    icon: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z",
    account: "@gaspardlz",
    meta: "Read-only",
    status: "error",
  },
];

const GROUPS: { label: string; keys: IntegrationKey[] }[] = [
  { label: "Voice assistant", keys: ["subyassist_bot"] },
  { label: "Calendar & Email", keys: ["google_calendar", "gmail"] },
  { label: "Messaging", keys: ["beeper", "telegram", "discord", "slack", "whatsapp"] },
  { label: "Social", keys: ["linkedin", "x"] },
];

const STATUS_META: Record<Status, { label: string; bg: string; color: string; dot: string }> = {
  connected: { label: "Connected", bg: "var(--gb)", color: "var(--gc)", dot: "var(--gc)" },
  disconnected: { label: "Not connected", bg: "var(--al)", color: "var(--t3)", dot: "var(--bd2)" },
  error: { label: "Reconnect", bg: "var(--rb)", color: "var(--rc)", dot: "var(--rc)" },
};

export function SettingsView() {
  const [integrations, setIntegrations] = useState<Integration[]>(INITIAL);
  const [pending, setPending] = useState<IntegrationKey | null>(null);

  const connectedCount = integrations.filter((i) => i.status === "connected").length;

  const toggle = (key: IntegrationKey) => {
    setPending(key);
    setTimeout(() => {
      setIntegrations((prev) =>
        prev.map((i) =>
          i.key === key
            ? {
                ...i,
                status: i.status === "connected" ? "disconnected" : "connected",
                account: i.status === "connected" ? undefined : i.account || "you@example.com",
                meta: i.status === "connected" ? undefined : "Just connected",
              }
            : i,
        ),
      );
      setPending(null);
    }, 700);
  };

  const byKey: Record<string, Integration> = Object.fromEntries(integrations.map((i) => [i.key, i]));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 28, maxWidth: 920 }}>
      <div>
        <h1 className="page-title">Settings</h1>
        <p style={{ color: "var(--t2)", fontSize: 13, marginTop: 4 }}>
          {connectedCount} of {integrations.length} integration{integrations.length === 1 ? "" : "s"} connected
        </p>
      </div>

      {GROUPS.map((group) => (
        <section key={group.label}>
          <div className="section-label" style={{ marginBottom: 12 }}>{group.label}</div>
          <div className="cd" style={{ overflow: "hidden" }}>
            {group.keys.map((k, idx) => {
              const i = byKey[k];
              if (!i) return null;
              const s = STATUS_META[i.status];
              const isLast = idx === group.keys.length - 1;
              const isPending = pending === i.key;
              const isConnected = i.status === "connected";

              return (
                <div
                  key={i.key}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 14,
                    padding: "14px 16px",
                    borderBottom: isLast ? "none" : "1px solid var(--bd)",
                  }}
                >
                  <div
                    style={{
                      width: 40, height: 40, borderRadius: 10,
                      background: i.bg,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill={i.color} aria-hidden>
                      <path d={i.icon} />
                    </svg>
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                      <span style={{ fontSize: 14, fontWeight: 600, color: "var(--t1)" }}>{i.name}</span>
                      <span
                        style={{
                          display: "inline-flex", alignItems: "center", gap: 5,
                          padding: "2px 8px", borderRadius: 999,
                          background: s.bg, color: s.color,
                          fontSize: 10, fontWeight: 600,
                        }}
                      >
                        <span style={{ width: 5, height: 5, borderRadius: "50%", background: s.dot }} />
                        {s.label}
                      </span>
                    </div>
                    <div style={{ fontSize: 12, color: "var(--t3)", marginTop: 2, lineHeight: 1.4 }}>
                      {i.description}
                    </div>
                    {isConnected && (i.account || i.meta) && (
                      <div style={{ display: "flex", gap: 8, marginTop: 6, flexWrap: "wrap" }}>
                        {i.account && (
                          <span className="mono" style={{ fontSize: 11, padding: "1px 7px", background: "var(--al)", borderRadius: 4, color: "var(--t2)" }}>
                            {i.account}
                          </span>
                        )}
                        {i.meta && (
                          <span style={{ fontSize: 11, color: "var(--t3)" }}>{i.meta}</span>
                        )}
                      </div>
                    )}
                  </div>

                  <button
                    className="btn btn-sm"
                    onClick={() => toggle(i.key)}
                    disabled={isPending}
                    style={{
                      background: isConnected ? "var(--sf)" : "var(--ac)",
                      color: isConnected ? "var(--t1)" : "white",
                      borderColor: isConnected ? "var(--bd)" : "var(--ac)",
                      minWidth: 100,
                    }}
                  >
                    {isPending
                      ? (isConnected ? "Disconnecting…" : "Connecting…")
                      : i.status === "error"
                      ? "Reconnect"
                      : isConnected
                      ? "Disconnect"
                      : "Connect"}
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      ))}

      {/* Data import section */}
      <section>
        <div className="section-label" style={{ marginBottom: 12 }}>Data import</div>
        <Link
          href="/dashboard/import"
          className="cd"
          style={{
            display: "flex", alignItems: "center", gap: 14,
            padding: "14px 16px", textDecoration: "none",
            color: "inherit", transition: "box-shadow 0.12s",
          }}
        >
          <div
            style={{
              width: 40, height: 40, borderRadius: 10,
              background: "var(--bb)", color: "var(--bc)",
              display: "flex", alignItems: "center", justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: "var(--t1)" }}>Import &amp; sync history</div>
            <div style={{ fontSize: 12, color: "var(--t3)", marginTop: 2 }}>
              View Beeper / Telegram / WhatsApp jobs and trigger a new import.
            </div>
          </div>
          <span style={{ fontSize: 13, color: "var(--t3)" }}>→</span>
        </Link>
      </section>

      <p style={{ fontSize: 11, color: "var(--t3)", textAlign: "center" }}>
        Need another integration? Drop a note in <span className="mono">#suby-feedback</span>.
      </p>
    </div>
  );
}
