"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { contactsApi, aiApi } from "@/lib/api";
import { MOCK_CONTACTS, MOCK_STATS } from "@/lib/mock-contacts";
import type { Contact, ContactType, ContactDomain } from "@/lib/types";
import { PlatformIcon } from "@/components/platform-icon";

function filterMock(params: Record<string, string>) {
  const page = parseInt(params.page || "1");
  const limit = parseInt(params.limit || "25");
  let data = MOCK_CONTACTS;
  if (params.type) data = data.filter((c) => c.type === params.type);
  if (params.domain) data = data.filter((c) => c.domain === params.domain);
  if (params.search) {
    const q = params.search.toLowerCase();
    data = data.filter((c) =>
      [c.name, c.company, c.role].filter(Boolean).join(" ").toLowerCase().includes(q),
    );
  }
  if (params.strength) data = data.filter((c) => c.relationshipStrength === params.strength);
  if (params.stale_days) {
    const days = parseInt(params.stale_days);
    const cutoff = Date.now() - days * 86400000;
    data = data.filter((c) => !c.lastContactDate || new Date(c.lastContactDate).getTime() < cutoff);
  }
  const total = data.length;
  data = data.slice((page - 1) * limit, page * limit);
  return { data, total, page, limit };
}

const TABS: { label: string; value: string }[] = [
  { label: "All", value: "" },
  { label: "VC", value: "vc" },
  { label: "Lead", value: "lead" },
  { label: "Partner", value: "partner" },
  { label: "Friend", value: "friend" },
  { label: "Prospect", value: "prospect" },
  { label: "Other", value: "other" },
];

const DOMAINS: { label: string; value: string }[] = [
  { label: "All domains", value: "" },
  { label: "Payment", value: "payment" },
  { label: "Blockchain", value: "blockchain" },
  { label: "SaaS", value: "saas" },
  { label: "E-commerce", value: "ecommerce" },
  { label: "AI", value: "ai" },
  { label: "Marketing", value: "marketing" },
  { label: "Legal", value: "legal" },
  { label: "Finance", value: "finance" },
  { label: "Other", value: "other" },
];

const TYPE_COLORS: Record<string, string> = {
  vc: "bdg-p", lead: "bdg-b", partner: "bdg-g", friend: "bdg-y", prospect: "bdg-o",
  team: "bdg-b", advisor: "bdg-p", media: "bdg-o", other: "bdg-b",
};

const DOMAIN_COLORS: Record<string, string> = {
  payment: "bdg-g", blockchain: "bdg-p", saas: "bdg-b", ecommerce: "bdg-o",
  ai: "bdg-p", marketing: "bdg-y", legal: "bdg-r", finance: "bdg-g", other: "bdg-b",
};

const STRENGTH_STYLES: Record<string, { cls: string }> = {
  cold: { cls: "bdg-b" },
  warm: { cls: "bdg-o" },
  hot: { cls: "bdg-r" },
};

function relativeDate(dateStr: string | null): string {
  if (!dateStr) return "Never";
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return "Today";
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days}d ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  if (days < 365) return `${Math.floor(days / 30)}mo ago`;
  return `${Math.floor(days / 365)}y ago`;
}

export function ContactsView() {
  const router = useRouter();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("");
  const [domain, setDomain] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [classifying, setClassifying] = useState(false);
  const [classifyResult, setClassifyResult] = useState<string | null>(null);
  const limit = 25;

  const fetchContacts = useCallback(() => {
    setLoading(true);
    const params: Record<string, string> = { page: String(page), limit: String(limit) };
    if (tab) params.type = tab;
    if (domain) params.domain = domain;
    if (search) params.search = search;
    contactsApi.getAll(params)
      .then((res) => {
        if (res.data?.length) {
          setContacts(res.data); setTotal(res.total);
        } else {
          const mock = filterMock(params);
          setContacts(mock.data); setTotal(mock.total);
        }
      })
      .catch(() => {
        const mock = filterMock(params);
        setContacts(mock.data); setTotal(mock.total);
      })
      .finally(() => setLoading(false));
  }, [tab, domain, search, page]);

  useEffect(() => {
    contactsApi.getStats()
      .then((s) => setCounts({ "": s.total, ...s.byType }))
      .catch(() => setCounts({ "": MOCK_STATS.total, ...MOCK_STATS.byType }));
  }, []);

  useEffect(() => { fetchContacts(); }, [fetchContacts]);

  const handleClassifyAll = async () => {
    setClassifying(true);
    setClassifyResult(null);
    try {
      const res = await aiApi.classifyBatch();
      setClassifyResult(`Queued ${res.queued} contacts for classification`);
      setTimeout(() => { fetchContacts(); setClassifyResult(null); }, 4000);
    } catch {
      setClassifyResult("Classification failed. Try again.");
    } finally {
      setClassifying(false);
    }
  };

  const totalPages = Math.ceil(total / limit);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <h1 className="page-title">Contacts</h1>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input
            placeholder="Search contacts..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            style={{ width: 220 }}
          />
          <select
            value={domain}
            onChange={(e) => { setDomain(e.target.value); setPage(1); }}
            style={{ height: 36, borderRadius: "var(--r)", border: "1px solid var(--bd)", background: "var(--sf)", color: "var(--t1)", fontSize: 13, padding: "0 10px" }}
          >
            {DOMAINS.map((d) => (
              <option key={d.value} value={d.value}>{d.label}</option>
            ))}
          </select>
          <button
            className="btn btn-p btn-sm"
            onClick={handleClassifyAll}
            disabled={classifying}
            style={{ whiteSpace: "nowrap" }}
          >
            {classifying ? "Classifying..." : "Classify All (AI)"}
          </button>
        </div>
      </div>

      {classifyResult && (
        <div style={{ padding: "10px 14px", background: "var(--gb)", color: "var(--gc)", borderRadius: "var(--r)", fontSize: 13, fontWeight: 500 }}>
          {classifyResult}
        </div>
      )}

      {/* Tabs */}
      <div className="tabs">
        {TABS.map((t) => (
          <button
            key={t.value}
            className={`tab ${tab === t.value ? "active" : ""}`}
            onClick={() => { setTab(t.value); setPage(1); }}
          >
            {t.label}{counts[t.value] !== undefined ? ` (${counts[t.value]})` : ""}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="cd" style={{ overflow: "auto" }}>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th className="hide-mobile">Platforms</th>
              <th>Type</th>
              <th className="hide-mobile">Domain</th>
              <th className="hide-mobile">Last contact</th>
              <th className="hide-mobile">Freq</th>
              <th>Strength</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} style={{ textAlign: "center", padding: 40 }}><span className="spinner" /></td></tr>
            ) : contacts.length === 0 ? (
              <tr><td colSpan={7} className="empty">No contacts found</td></tr>
            ) : contacts.map((c) => (
              <tr key={c.id} style={{ cursor: "pointer" }} onClick={() => router.push(`/dashboard/contacts/${c.id}`)}>
                <td>
                  <div style={{ fontWeight: 500 }}>{c.name}</div>
                  {(c.company || c.role) && (
                    <div style={{ fontSize: 12, color: "var(--t3)", marginTop: 2 }}>
                      {[c.role, c.company].filter(Boolean).join(" @ ")}
                    </div>
                  )}
                </td>
                <td className="hide-mobile">
                  <div style={{ display: "flex", gap: 4 }}>
                    {c.platforms?.map((p) => (
                      <span key={p.id} title={`${p.type}${p.displayName ? `: ${p.displayName}` : ""}`} style={{
                        display: "inline-flex", alignItems: "center", justifyContent: "center",
                        width: 26, height: 26, borderRadius: 6, background: "var(--al)", border: "1px solid var(--bd)",
                      }}>
                        <PlatformIcon type={p.type} size={14} />
                      </span>
                    ))}
                    {(!c.platforms || c.platforms.length === 0) && <span style={{ color: "var(--t3)", fontSize: 12 }}>--</span>}
                  </div>
                </td>
                <td><span className={`bdg ${TYPE_COLORS[c.type] || "bdg-b"}`}>{c.type}</span></td>
                <td className="hide-mobile"><span className={`bdg ${DOMAIN_COLORS[c.domain] || "bdg-b"}`}>{c.domain}</span></td>
                <td className="hide-mobile">
                  <span className="mono" style={{ color: "var(--t2)", fontSize: 12 }}>{relativeDate(c.lastContactDate)}</span>
                </td>
                <td className="hide-mobile">
                  {c.contactFrequency != null && c.contactFrequency > 0 ? (
                    <span className="mono" style={{ fontSize: 12, color: "var(--t2)" }}>{c.contactFrequency}</span>
                  ) : (
                    <span style={{ color: "var(--t3)", fontSize: 12 }}>--</span>
                  )}
                </td>
                <td><span className={`bdg ${STRENGTH_STYLES[c.relationshipStrength]?.cls || "bdg-b"}`}>{c.relationshipStrength}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
          <button className="btn btn-sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
          <span style={{ fontSize: 13, color: "var(--t2)" }}>Page {page} of {totalPages} ({total} contacts)</span>
          <button className="btn btn-sm" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
