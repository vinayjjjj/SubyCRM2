"use client";

import { useState, useEffect, useMemo } from "react";
import { remindersApi } from "@/lib/api";
import { MOCK_REMINDERS } from "@/lib/mock-reminders";
import { MOCK_CONTACTS } from "@/lib/mock-contacts";
import { PlatformIcon } from "@/components/platform-icon";
import type { Reminder, ReminderStatus, PlatformType, Contact } from "@/lib/types";

type Bucket = "overdue" | "today" | "this_week" | "later";

const BUCKETS: { key: Bucket; label: string; tone: string }[] = [
  { key: "overdue", label: "Overdue", tone: "var(--rc)" },
  { key: "today", label: "Today", tone: "var(--oc)" },
  { key: "this_week", label: "This week", tone: "var(--bc)" },
  { key: "later", label: "Later", tone: "var(--t3)" },
];

const BUCKET_BG: Record<Bucket, string> = {
  overdue: "var(--rb)",
  today: "var(--ob)",
  this_week: "var(--bb)",
  later: "var(--al)",
};

function bucketOf(dueDate: string): Bucket {
  const now = new Date();
  const due = new Date(dueDate);
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const endOfToday = startOfToday + 86400000;
  const endOfWeek = startOfToday + 7 * 86400000;
  const t = due.getTime();
  if (t < startOfToday) return "overdue";
  if (t < endOfToday) return "today";
  if (t < endOfWeek) return "this_week";
  return "later";
}

function formatDue(dueDate: string): string {
  const now = new Date();
  const due = new Date(dueDate);
  const diffMs = due.getTime() - now.getTime();
  const days = Math.round(diffMs / 86400000);
  const sameDay = due.toDateString() === now.toDateString();
  if (sameDay) {
    const h = due.getHours().toString().padStart(2, "0");
    const m = due.getMinutes().toString().padStart(2, "0");
    return `${h}:${m}`;
  }
  if (days < -1) return `${-days}d ago`;
  if (days === -1) return "Yesterday";
  if (days === 1) return "Tomorrow";
  if (days < 7) return `In ${days}d`;
  return due.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function initials(name: string): string {
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || "").join("");
}

const CONTACT_LOOKUP: Record<string, Contact> = Object.fromEntries(
  MOCK_CONTACTS.map((c) => [c.id, c]),
);

function lastChannel(contactId: string): PlatformType | null {
  const c = CONTACT_LOOKUP[contactId];
  if (!c) return null;
  const interactions = c.interactions || [];
  if (interactions.length > 0) {
    const latest = [...interactions].sort(
      (a, b) => +new Date(b.occurredAt) - +new Date(a.occurredAt),
    )[0];
    return latest.platform;
  }
  return c.platforms?.[0]?.type || null;
}

export function RemindersView() {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState<Bucket | null>(null);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);

  useEffect(() => {
    if (selectedContact) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => { document.body.style.overflow = prev; };
    }
  }, [selectedContact]);

  useEffect(() => {
    remindersApi.getAll()
      .then((data) => setReminders(data?.length ? data : MOCK_REMINDERS))
      .catch(() => setReminders(MOCK_REMINDERS))
      .finally(() => setLoading(false));
  }, []);

  const setStatus = (id: string, next: ReminderStatus) => {
    setReminders((prev) => prev.map((r) => (r.id === id ? { ...r, status: next } : r)));
    remindersApi.update(id, { status: next }).catch(() => {});
  };

  const moveToBucket = (id: string, target: Bucket) => {
    const now = new Date();
    let due = new Date();
    if (target === "overdue") due = new Date(now.getTime() - 2 * 86400000);
    else if (target === "today") due = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 17, 0);
    else if (target === "this_week") due = new Date(now.getTime() + 3 * 86400000);
    else due = new Date(now.getTime() + 14 * 86400000);

    const iso = due.toISOString();
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, dueDate: iso, status: "pending" } : r)),
    );
    remindersApi.update(id, { dueDate: iso, status: "pending" }).catch(() => {});
  };

  const grouped = useMemo(() => {
    const q = query.trim().toLowerCase();
    const groups: Record<Bucket, Reminder[]> = { overdue: [], today: [], this_week: [], later: [] };
    for (const r of reminders) {
      if (r.status !== "pending") continue;
      if (q) {
        const hay = [r.content, r.contact?.name].filter(Boolean).join(" ").toLowerCase();
        if (!hay.includes(q)) continue;
      }
      groups[bucketOf(r.dueDate)].push(r);
    }
    for (const k of Object.keys(groups) as Bucket[]) {
      groups[k].sort((a, b) => +new Date(a.dueDate) - +new Date(b.dueDate));
    }
    return groups;
  }, [reminders, query]);

  const totalPending = reminders.filter((r) => r.status === "pending").length;
  const overdueCount = grouped.overdue.length;

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 80 }}>
        <span className="spinner" style={{ width: 20, height: 20, color: "var(--t3)" }} />
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 className="page-title">Reminders</h1>
          <p style={{ color: "var(--t2)", fontSize: 13, marginTop: 4 }}>
            {totalPending} pending
            {overdueCount > 0 && (
              <span style={{ color: "var(--rc)", fontWeight: 500 }}> · {overdueCount} overdue</span>
            )}
          </p>
        </div>
        <input
          placeholder="Search..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={{ width: 240 }}
        />
      </div>

      <div className="kanban">
        {BUCKETS.map(({ key, label, tone }) => {
          const items = grouped[key];
          const isDragTarget = dragOver === key;
          return (
            <div
              key={key}
              className="kanban-col"
              onDragOver={(e) => { e.preventDefault(); setDragOver(key); }}
              onDragLeave={() => setDragOver((d) => (d === key ? null : d))}
              onDrop={(e) => {
                e.preventDefault();
                if (draggedId) moveToBucket(draggedId, key);
                setDraggedId(null);
                setDragOver(null);
              }}
              style={{
                background: isDragTarget ? BUCKET_BG[key] : "var(--sf2)",
                outline: isDragTarget ? `2px dashed ${tone}` : "1px solid var(--bd)",
                outlineOffset: isDragTarget ? -2 : 0,
              }}
            >
              <div className="kanban-head">
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ width: 8, height: 8, borderRadius: "50%", background: tone }} />
                  <span style={{ fontSize: 12, fontWeight: 600, color: "var(--t1)", textTransform: "uppercase", letterSpacing: 0.04 }}>
                    {label}
                  </span>
                </div>
                <span style={{ fontSize: 11, fontWeight: 600, color: "var(--t2)", background: "var(--sf)", padding: "1px 8px", borderRadius: 10, border: "1px solid var(--bd)" }}>
                  {items.length}
                </span>
              </div>

              <div className="kanban-body">
                {items.length === 0 ? (
                  <div style={{ fontSize: 12, color: "var(--t3)", textAlign: "center", padding: "16px 8px" }}>
                    Nothing here.
                  </div>
                ) : (
                  items.map((r) => (
                    <ReminderCard
                      key={r.id}
                      reminder={r}
                      channel={lastChannel(r.contactId)}
                      tone={tone}
                      onDragStart={() => setDraggedId(r.id)}
                      onDragEnd={() => { setDraggedId(null); setDragOver(null); }}
                      onDone={() => setStatus(r.id, "done")}
                      onOpen={() => {
                        const c = CONTACT_LOOKUP[r.contactId];
                        if (c) setSelectedContact(c);
                      }}
                    />
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {selectedContact && (
        <ContactModal contact={selectedContact} onClose={() => setSelectedContact(null)} />
      )}

      <style jsx>{`
        .kanban {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 12px;
          align-items: start;
        }
        .kanban-col {
          border-radius: var(--r2);
          padding: 10px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          min-height: 240px;
          transition: background 0.12s, outline-color 0.12s;
        }
        .kanban-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 2px 4px;
        }
        .kanban-body {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        @media (max-width: 1100px) {
          .kanban { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 640px) {
          .kanban { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
}

function ReminderCard({
  reminder,
  channel,
  tone,
  onDragStart,
  onDragEnd,
  onDone,
  onOpen,
}: {
  reminder: Reminder;
  channel: PlatformType | null;
  tone: string;
  onDragStart: () => void;
  onDragEnd: () => void;
  onDone: () => void;
  onOpen: () => void;
}) {
  const [hover, setHover] = useState(false);
  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: "var(--sf)",
        border: "1px solid var(--bd)",
        borderLeft: `3px solid ${tone}`,
        borderRadius: var_r(),
        padding: "10px 12px",
        cursor: "grab",
        boxShadow: hover ? "var(--shadow)" : "var(--shadow-sm)",
        transition: "box-shadow 0.12s, transform 0.12s",
        transform: hover ? "translateY(-1px)" : "none",
        display: "flex",
        flexDirection: "column",
        gap: 8,
      }}
    >
      <div style={{ fontSize: 13, fontWeight: 500, color: "var(--t1)", lineHeight: 1.4 }}>
        {reminder.content}
      </div>

      {reminder.contact && (
        <button
          onClick={onOpen}
          className="contact-link"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            background: "var(--al)",
            border: "1px solid var(--bd)",
            padding: "4px 8px 4px 4px",
            borderRadius: 999,
            cursor: "pointer",
            textAlign: "left",
            alignSelf: "flex-start",
            transition: "background 0.12s, border-color 0.12s",
          }}
        >
          <span
            style={{
              width: 20, height: 20, borderRadius: "50%",
              background: "var(--sf)", color: "var(--t2)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 10, fontWeight: 700, flexShrink: 0,
              border: "1px solid var(--bd)",
            }}
          >
            {initials(reminder.contact.name)}
          </span>
          <span style={{ fontSize: 12, color: "var(--t1)", fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {reminder.contact.name}
          </span>
          {channel && (
            <span
              title={`Last talked on ${channel}`}
              style={{
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                width: 18, height: 18, borderRadius: 4,
                background: "var(--sf)", border: "1px solid var(--bd)",
                flexShrink: 0,
              }}
            >
              <PlatformIcon type={channel} size={11} />
            </span>
          )}
          <style jsx>{`
            .contact-link:hover {
              background: var(--sf) !important;
              border-color: var(--bd2) !important;
            }
          `}</style>
        </button>
      )}

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span className="mono" style={{ fontSize: 11, color: tone, fontWeight: 500 }}>
          {formatDue(reminder.dueDate)}
        </span>
        <button
          aria-label="Mark done"
          onClick={onDone}
          style={{
            opacity: hover ? 1 : 0,
            transition: "opacity 0.12s",
            background: "var(--gb)", color: "var(--gc)",
            border: "none", borderRadius: 6,
            padding: "3px 8px", fontSize: 11, fontWeight: 600,
            cursor: "pointer",
            display: "flex", alignItems: "center", gap: 4,
          }}
        >
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
          Done
        </button>
      </div>
    </div>
  );
}

function var_r(): string {
  return "10px";
}

function ContactModal({ contact, onClose }: { contact: Contact; onClose: () => void }) {
  const recent = (contact.interactions || []).slice(0, 5);
  const notes = contact.notes || [];

  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)",
        display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: 100, padding: 20,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "var(--sf)", borderRadius: 16, boxShadow: "0 12px 40px rgba(0,0,0,0.18)",
          width: "100%", maxWidth: 560, maxHeight: "85vh", overflow: "hidden",
          display: "flex", flexDirection: "column",
        }}
      >
        {/* Header */}
        <div style={{ padding: "18px 22px", borderBottom: "1px solid var(--bd)", display: "flex", alignItems: "flex-start", gap: 14 }}>
          <div
            style={{
              width: 48, height: 48, borderRadius: "50%",
              background: "var(--al)", color: "var(--t2)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16, fontWeight: 700, flexShrink: 0,
            }}
          >
            {initials(contact.name)}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: "var(--t1)", letterSpacing: "-0.02em" }}>
              {contact.name}
            </div>
            {(contact.role || contact.company) && (
              <div style={{ fontSize: 13, color: "var(--t2)", marginTop: 2 }}>
                {[contact.role, contact.company].filter(Boolean).join(" @ ")}
              </div>
            )}
            <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
              <span className="bdg bdg-p">{contact.type}</span>
              <span className="bdg bdg-b">{contact.domain}</span>
              <span className={`bdg ${contact.relationshipStrength === "hot" ? "bdg-r" : contact.relationshipStrength === "warm" ? "bdg-o" : "bdg-b"}`}>
                {contact.relationshipStrength}
              </span>
            </div>
          </div>
          <button
            aria-label="Close"
            onClick={onClose}
            style={{
              background: "var(--al)", border: "none", color: "var(--t2)",
              width: 30, height: 30, borderRadius: 8,
              display: "flex", alignItems: "center", justifyContent: "center",
              cursor: "pointer", flexShrink: 0,
            }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div style={{ overflowY: "auto", padding: "18px 22px", display: "flex", flexDirection: "column", gap: 18 }}>
          {/* Platforms */}
          {contact.platforms && contact.platforms.length > 0 && (
            <div>
              <div className="section-label" style={{ marginBottom: 8 }}>Reach on</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {contact.platforms.map((p) => (
                  <span
                    key={p.id}
                    style={{
                      display: "inline-flex", alignItems: "center", gap: 6,
                      padding: "5px 10px", borderRadius: 999,
                      background: "var(--al)", border: "1px solid var(--bd)",
                      fontSize: 12, color: "var(--t1)",
                    }}
                  >
                    <PlatformIcon type={p.type as PlatformType} size={12} />
                    <span className="mono" style={{ fontSize: 11 }}>{p.platformId}</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Recent exchanges */}
          {recent.length > 0 && (
            <div>
              <div className="section-label" style={{ marginBottom: 8 }}>Recent exchanges</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {recent.map((i) => (
                  <div
                    key={i.id}
                    style={{
                      display: "flex", alignItems: "flex-start", gap: 10,
                      padding: "8px 10px",
                      background: "var(--sf2)", borderRadius: 8, border: "1px solid var(--bd)",
                    }}
                  >
                    <PlatformIcon type={i.platform} size={14} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12, color: "var(--t1)", lineHeight: 1.4 }}>
                        {i.contentSnippet}
                      </div>
                      <div style={{ fontSize: 10, color: "var(--t3)", marginTop: 2 }}>
                        {i.direction === "outbound" ? "Sent" : "Received"} ·{" "}
                        {new Date(i.occurredAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {notes.length > 0 && (
            <div>
              <div className="section-label" style={{ marginBottom: 8 }}>Notes</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {notes.map((n) => (
                  <div
                    key={n.id}
                    style={{
                      padding: "10px 12px",
                      background: "var(--yb)",
                      border: "1px solid #f5e1a0",
                      borderRadius: 8,
                      fontSize: 12,
                      color: "var(--t1)",
                      lineHeight: 1.5,
                    }}
                  >
                    {n.content}
                  </div>
                ))}
              </div>
            </div>
          )}

          {recent.length === 0 && notes.length === 0 && (
            <div className="empty" style={{ padding: 24, fontSize: 13 }}>
              No history yet for this contact.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
