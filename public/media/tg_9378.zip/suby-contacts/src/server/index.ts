process.on("uncaughtException", (err) => {
  console.error("[uncaughtException]", err.message);
});
process.on("unhandledRejection", (err) => {
  console.error("[unhandledRejection]", err);
});

import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { errorMiddleware } from "./middlewares/error";

// Routes
import contactRoutes from "./routes/contact.routes";
import { tagRouter, contactTagRouter } from "./routes/tag.routes";
import { contactNoteRouter, noteRouter } from "./routes/note.routes";
import importRoutes from "./routes/import.routes";
import aiRoutes from "./routes/ai.routes";
import companyRoutes from "./routes/company.routes";
import reminderRoutes, { contactReminderRouter } from "./routes/reminder.routes";

const app = express();
const PORT = process.env.API_PORT || 4002;

// ─── CORS ────────────────────────────────────────────────────
const allowedOrigins = process.env.FRONTEND_URL
  ? process.env.FRONTEND_URL.split(",").map((s) => s.trim())
  : [];

app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (curl, server-to-server)
    if (!origin) return callback(null, true);
    // Allow all in dev
    if (process.env.NODE_ENV !== "production") return callback(null, true);
    // Check allowed origins in prod
    if (allowedOrigins.includes(origin)) return callback(null, true);
    callback(new Error("CORS not allowed"));
  },
  credentials: true,
}));

app.use(express.json({ limit: "50kb" }));

// ─── Rate limiting ──────────────────────────────────────────
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 2000,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests, try again later" },
  })
);

// ─── Health check ────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "suby-contacts" });
});

// ─── Routes ──────────────────────────────────────────────────
app.use("/api/contacts", contactRoutes);
app.use("/api/contacts", contactTagRouter);
app.use("/api/contacts", contactNoteRouter);
app.use("/api/tags", tagRouter);
app.use("/api/notes", noteRouter);
app.use("/api/imports", importRoutes);
app.use("/api/ai", aiRoutes);
app.use("/api/companies", companyRoutes);
app.use("/api/reminders", reminderRoutes);
app.use("/api/contacts", contactReminderRouter);

// ─── Error handler ───────────────────────────────────────────
app.use(errorMiddleware);

// ─── Cron: stale contact check (daily) ──────────────────────
import cron from "node-cron";
import { runStaleCheck } from "./cron/staleCheck";
cron.schedule("0 8 * * *", () => runStaleCheck().catch(console.error));

// ─── Start server ────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Suby Contacts API running on port ${PORT}`);
});

export default app;
