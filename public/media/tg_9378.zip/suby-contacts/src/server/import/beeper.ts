import Database from "better-sqlite3";
import path from "path";
import os from "os";

const BEEPER_BASE = path.join(os.homedir(), "Library", "Application Support", "BeeperTexts");

interface BeeperContact {
  id: string;
  name: string;
  identifiers: string[]; // tel:+xxx, telegram:handle, etc.
  platform: "whatsapp" | "telegram" | "x" | "linkedin";
  messageCount: number;
  lastMessageTs: number | null; // unix ms
  firstMessageTs: number | null;
}

const PLATFORM_MAP: Record<string, "whatsapp" | "telegram" | "x" | "linkedin"> = {
  "local-whatsapp": "whatsapp",
  "local-telegram": "telegram",
  "local-twitter": "x",
  "local-linkedin": "linkedin",
};

function extractPlatformId(identifiers: string[], platform: string): string {
  for (const id of identifiers) {
    if (id.startsWith("tel:")) return id.replace("tel:", "");
    if (id.startsWith("telegram:")) return "@" + id.replace("telegram:", "");
  }
  return "";
}

function nsToMs(ns: number | null): number | null {
  if (!ns) return null;
  return Math.floor(ns / 1_000_000);
}

export function importFromBeeper(): { contacts: BeeperContact[]; errors: string[] } {
  const contacts: BeeperContact[] = [];
  const errors: string[] = [];
  const seen = new Set<string>(); // deduplicate by name within a platform

  for (const [dir, platform] of Object.entries(PLATFORM_MAP)) {
    const dbPath = path.join(BEEPER_BASE, dir, "megabridge.db");
    try {
      const db = new Database(dbPath, { readonly: true });

      // Get all ghosts (contacts) with message stats
      const rows = db.prepare(`
        SELECT
          g.id,
          g.name,
          g.identifiers,
          COALESCE(stats.msg_count, 0) as msg_count,
          stats.last_ts,
          stats.first_ts
        FROM ghost g
        LEFT JOIN (
          SELECT
            sender_id,
            COUNT(*) as msg_count,
            MAX(timestamp) as last_ts,
            MIN(timestamp) as first_ts
          FROM message
          GROUP BY sender_id
        ) stats ON g.id = stats.sender_id
        WHERE g.name != '' AND g.name NOT LIKE '%Suby%'
        ORDER BY stats.last_ts DESC NULLS LAST
      `).all() as any[];

      for (const row of rows) {
        // Skip self and duplicates (Beeper creates lid-xxx aliases)
        const key = `${platform}:${row.name}`;
        if (seen.has(key)) continue;
        seen.add(key);

        let identifiers: string[] = [];
        try {
          identifiers = JSON.parse(row.identifiers || "[]");
        } catch {}

        const platformId = extractPlatformId(identifiers, platform) || row.id;

        contacts.push({
          id: row.id,
          name: row.name.trim(),
          identifiers,
          platform,
          messageCount: row.msg_count,
          lastMessageTs: nsToMs(row.last_ts),
          firstMessageTs: nsToMs(row.first_ts),
        });
      }

      db.close();
      console.log(`[beeper] ${platform}: ${rows.length} raw contacts`);
    } catch (err) {
      const msg = `Failed to read ${platform}: ${err instanceof Error ? err.message : String(err)}`;
      errors.push(msg);
      console.error(`[beeper] ${msg}`);
    }
  }

  console.log(`[beeper] Total: ${contacts.length} contacts (before dedup)`);
  return { contacts, errors };
}

// Get last N message snippets for a contact (for AI classification)
export function getMessageSnippets(platform: string, contactId: string, limit: number = 10): string[] {
  const dirMap: Record<string, string> = { whatsapp: "local-whatsapp", telegram: "local-telegram", x: "local-twitter", linkedin: "local-linkedin" };
  const dir = dirMap[platform];
  if (!dir) return [];

  const dbPath = path.join(BEEPER_BASE, dir, "megabridge.db");
  try {
    const db = new Database(dbPath, { readonly: true });

    // Try to get message content from the message table + local_events if available
    // Messages are stored differently per bridge - try portal-based approach
    const rows = db.prepare(`
      SELECT m.timestamp, m.sender_id
      FROM message m
      WHERE m.sender_id = ? OR m.room_id IN (
        SELECT p.id FROM portal p WHERE p.other_user_id = ?
      )
      ORDER BY m.timestamp DESC
      LIMIT ?
    `).all(contactId, contactId, limit) as any[];

    db.close();
    return rows.map((r: any) => {
      const date = new Date(Math.floor(r.timestamp / 1_000_000));
      return `[${date.toISOString().slice(0, 10)}] ${r.sender_id === contactId ? "them" : "you"}`;
    });
  } catch {
    return [];
  }
}
