import { Router } from "express";
import { contactService } from "../services/contact.service";
import { enrichmentService } from "../services/enrichment.service";

const router = Router();

// GET /api/contacts — list all with filters
router.get("/", async (req, res, next) => {
  try {
    const result = await contactService.getAll({
      type: req.query.type as string | undefined,
      domain: req.query.domain as string | undefined,
      strength: req.query.strength as string | undefined,
      tag: req.query.tag as string | undefined,
      search: req.query.search as string | undefined,
      stale_days: req.query.stale_days ? Number(req.query.stale_days) : undefined,
      page: req.query.page ? Number(req.query.page) : undefined,
      limit: req.query.limit ? Number(req.query.limit) : undefined,
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

// GET /api/contacts/stats — aggregated stats
router.get("/stats", async (_req, res, next) => {
  try {
    const stats = await contactService.getStats();
    res.json(stats);
  } catch (err) {
    next(err);
  }
});

// GET /api/contacts/:id — single contact with relations
router.get("/:id", async (req, res, next) => {
  try {
    const contact = await contactService.getById(req.params.id);
    if (!contact) {
      res.status(404).json({ error: "Contact not found" });
      return;
    }
    res.json(contact);
  } catch (err) {
    next(err);
  }
});

// POST /api/contacts — create contact
router.post("/", async (req, res, next) => {
  try {
    const { name } = req.body;
    if (!name || typeof name !== "string") {
      res.status(400).json({ error: "Missing name" });
      return;
    }
    const contact = await contactService.create(req.body);
    res.status(201).json(contact);
  } catch (err) {
    next(err);
  }
});

// PUT /api/contacts/:id — update contact
router.put("/:id", async (req, res, next) => {
  try {
    const contact = await contactService.update(req.params.id, req.body);
    res.json(contact);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/contacts/:id — delete contact
router.delete("/:id", async (req, res, next) => {
  try {
    await contactService.delete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// POST /api/contacts/:id/merge — merge another contact into this one
router.post("/:id/merge", async (req, res, next) => {
  try {
    const { mergeWithId } = req.body;
    if (!mergeWithId || typeof mergeWithId !== "string") {
      res.status(400).json({ error: "Missing mergeWithId" });
      return;
    }
    if (mergeWithId === req.params.id) {
      res.status(400).json({ error: "Cannot merge contact with itself" });
      return;
    }
    const result = await contactService.merge(req.params.id, mergeWithId);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

// POST /api/contacts/:id/enrich — enrich contact via SerpAPI
router.post("/:id/enrich", async (req, res, next) => {
  try {
    const result = await enrichmentService.enrichContact(req.params.id);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
