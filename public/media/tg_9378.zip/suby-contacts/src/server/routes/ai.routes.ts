import { Router } from "express";
import { prisma } from "../lib/prisma";
import { aiService } from "../services/ai.service";

const router = Router();

// POST /api/ai/classify/:id — classify a contact with AI
router.post("/classify/:id", async (req, res, next) => {
  try {
    const contact = await prisma.contact.findUnique({
      where: { id: req.params.id },
      include: {
        platforms: true,
        interactions: { orderBy: { occurredAt: "desc" }, take: 20 },
      },
    });

    if (!contact) {
      res.status(404).json({ error: "Contact not found" });
      return;
    }

    const classification = await aiService.classifyContact(contact);

    // Update the contact with AI classification
    const updated = await prisma.contact.update({
      where: { id: req.params.id },
      data: {
        type: classification.type as any,
        domain: classification.domain as any,
      },
    });

    res.json({ classification, contact: updated });
  } catch (err) {
    next(err);
  }
});

// POST /api/ai/summary/:id — generate AI summary for a contact
router.post("/summary/:id", async (req, res, next) => {
  try {
    const contact = await prisma.contact.findUnique({
      where: { id: req.params.id },
      include: {
        platforms: true,
        interactions: { orderBy: { occurredAt: "desc" }, take: 20 },
        notes: { orderBy: { createdAt: "desc" }, take: 10 },
        contactTags: { include: { tag: true } },
      },
    });

    if (!contact) {
      res.status(404).json({ error: "Contact not found" });
      return;
    }

    const summary = await aiService.generateSummary(contact);

    // Save summary to contact
    const updated = await prisma.contact.update({
      where: { id: req.params.id },
      data: { aiSummary: summary },
    });

    res.json({ summary, contact: updated });
  } catch (err) {
    next(err);
  }
});

// POST /api/ai/prep/:id — generate meeting prep (stub)
router.post("/prep/:id", async (req, res, next) => {
  try {
    const contact = await prisma.contact.findUnique({
      where: { id: req.params.id },
      include: {
        platforms: true,
        interactions: { orderBy: { occurredAt: "desc" }, take: 20 },
        notes: { orderBy: { createdAt: "desc" }, take: 10 },
        contactTags: { include: { tag: true } },
      },
    });

    if (!contact) {
      res.status(404).json({ error: "Contact not found" });
      return;
    }

    const prep = await aiService.generatePrep(contact);
    res.json(prep);
  } catch (err) {
    next(err);
  }
});

// POST /api/ai/classify-batch — classify all unclassified contacts
router.post("/classify-batch", async (_req, res, next) => {
  try {
    const unclassified = await prisma.contact.findMany({
      where: { type: "other", domain: "other" },
      include: { platforms: true, interactions: { orderBy: { occurredAt: "desc" }, take: 5 } },
      take: 50,
    });

    res.json({ status: "started", total: unclassified.length });

    // Run in background
    (async () => {
      let classified = 0;
      for (const contact of unclassified) {
        try {
          const result = await aiService.classifyContact(contact);
          await prisma.contact.update({
            where: { id: contact.id },
            data: { type: result.type as any, domain: result.domain as any },
          });
          classified++;
          if (classified % 10 === 0) console.log(`[ai] Classified ${classified}/${unclassified.length}`);
        } catch (err) {
          console.error(`[ai] Failed to classify ${contact.name}:`, err);
        }
      }
      console.log(`[ai] Batch classification done: ${classified}/${unclassified.length}`);
    })().catch(console.error);
  } catch (err) {
    next(err);
  }
});

// GET /api/ai/alerts — get AI-generated alerts
router.get("/alerts", async (_req, res, next) => {
  try {
    const alerts = await aiService.getAlerts();
    res.json(alerts);
  } catch (err) {
    next(err);
  }
});

export default router;
