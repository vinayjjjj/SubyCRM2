import { Router } from "express";
import { prisma } from "../lib/prisma";
import { contactService } from "../services/contact.service";
import { importService } from "../services/import.service";

const router = Router();

// GET /api/imports — list all import jobs
router.get("/", async (_req, res, next) => {
  try {
    const jobs = await prisma.importJob.findMany({
      orderBy: { createdAt: "desc" },
    });
    res.json(jobs);
  } catch (err) {
    next(err);
  }
});

// GET /api/imports/:id — single import job
router.get("/:id", async (req, res, next) => {
  try {
    const job = await prisma.importJob.findUnique({
      where: { id: req.params.id },
    });
    if (!job) {
      res.status(404).json({ error: "Import job not found" });
      return;
    }
    res.json(job);
  } catch (err) {
    next(err);
  }
});

// POST /api/imports/manual — manually create a contact via import flow
router.post("/manual", async (req, res, next) => {
  try {
    const { name } = req.body;
    if (!name || typeof name !== "string") {
      res.status(400).json({ error: "Missing name" });
      return;
    }

    // Create an import job record
    const job = await prisma.importJob.create({
      data: {
        source: "manual",
        status: "completed",
        totalFound: 1,
        imported: 1,
        startedAt: new Date(),
        completedAt: new Date(),
      },
    });

    // Create the contact
    const contact = await contactService.create(req.body);

    res.status(201).json({ job, contact });
  } catch (err) {
    next(err);
  }
});

// POST /api/imports/beeper — trigger Beeper import
router.post("/beeper", async (_req, res, next) => {
  try {
    res.json({ status: "started", message: "Beeper import running in background" });
    // Run in background (don't await)
    importService.runBeeperImport().catch(console.error);
  } catch (err) {
    next(err);
  }
});

export default router;
