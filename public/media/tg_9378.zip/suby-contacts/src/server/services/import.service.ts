import { prisma } from "../lib/prisma";
import { importFromBeeper } from "../import/beeper";
import { deduplicateContacts } from "./dedup.service";
import type { PlatformType } from "@prisma/client";

function extractPlatformId(identifiers: string[], rawId: string, platform: string): string {
  for (const id of identifiers) {
    if (id.startsWith("tel:")) return id.replace("tel:", "");
    if (id.startsWith("telegram:")) return "@" + id.replace("telegram:", "");
  }
  // For Twitter/LinkedIn, use raw ID
  return rawId;
}

function extractProfileUrl(platform: string, identifiers: string[], rawId: string): string | null {
  for (const id of identifiers) {
    if (platform === "telegram" && id.startsWith("telegram:"))
      return `https://t.me/${id.replace("telegram:", "")}`;
  }
  if (platform === "x") return `https://x.com/i/user/${rawId}`;
  if (platform === "linkedin") return `https://linkedin.com/in/${rawId}`;
  return null;
}

export const importService = {
  async runBeeperImport(): Promise<string> {
    // Create import job
    const job = await prisma.importJob.create({
      data: { source: "beeper", status: "running", startedAt: new Date() },
    });

    try {
      const { contacts, errors } = importFromBeeper();
      let imported = 0;
      let skipped = 0;

      await prisma.importJob.update({
        where: { id: job.id },
        data: { totalFound: contacts.length },
      });

      for (const c of contacts) {
        try {
          // Skip empty names
          if (!c.name || c.name.length < 2) { skipped++; continue; }

          const platformId = extractPlatformId(c.identifiers, c.id, c.platform);
          if (!platformId) { skipped++; continue; }

          // Check if platform already exists (avoid duplicates on re-import)
          const existing = await prisma.platform.findUnique({
            where: { type_platformId: { type: c.platform as PlatformType, platformId } },
          });

          if (existing) {
            // Update last contact date if we have newer data
            if (c.lastMessageTs) {
              const contact = await prisma.contact.findUnique({ where: { id: existing.contactId } });
              if (contact && (!contact.lastContactDate || new Date(c.lastMessageTs) > contact.lastContactDate)) {
                await prisma.contact.update({
                  where: { id: existing.contactId },
                  data: {
                    lastContactDate: new Date(c.lastMessageTs),
                    contactFrequency: c.messageCount > 0 ? c.messageCount : undefined,
                  },
                });
              }
            }
            skipped++;
            continue;
          }

          // Create new contact with platform
          await prisma.contact.create({
            data: {
              name: c.name,
              lastContactDate: c.lastMessageTs ? new Date(c.lastMessageTs) : null,
              firstContactDate: c.firstMessageTs ? new Date(c.firstMessageTs) : null,
              contactFrequency: c.messageCount > 0 ? c.messageCount : null,
              platforms: {
                create: [{
                  type: c.platform as PlatformType,
                  platformId,
                  displayName: c.name,
                  profileUrl: extractProfileUrl(c.platform, c.identifiers, c.id),
                }],
              },
            },
          });
          imported++;
        } catch (err) {
          // Skip individual contact errors (constraint violations, etc.)
          skipped++;
        }
      }

      // Run deduplication
      console.log(`[import] Running deduplication...`);
      const dedup = await deduplicateContacts();

      await prisma.importJob.update({
        where: { id: job.id },
        data: {
          status: "completed",
          imported,
          deduplicated: dedup.mergedCount,
          errors: skipped,
          errorLog: errors.length > 0 ? errors : undefined,
          completedAt: new Date(),
        },
      });

      console.log(`[import] Done: ${imported} imported, ${dedup.mergedCount} deduplicated, ${skipped} skipped`);
      return job.id;
    } catch (err) {
      await prisma.importJob.update({
        where: { id: job.id },
        data: {
          status: "failed",
          errorLog: { error: err instanceof Error ? err.message : String(err) },
          completedAt: new Date(),
        },
      });
      throw err;
    }
  },
};
