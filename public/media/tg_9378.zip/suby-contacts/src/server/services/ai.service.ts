import { anthropic, CHAT_MODEL } from "../lib/anthropic";

interface ClassifyResult {
  type: string;
  domain: string;
  confidence: number;
}

interface ContactForAI {
  id: string;
  name: string;
  company?: string | null;
  role?: string | null;
  platforms: Array<{ type: string; displayName?: string | null }>;
  interactions: Array<{
    platform: string;
    direction: string;
    contentSnippet?: string | null;
    occurredAt: Date;
  }>;
  notes?: Array<{ content: string }>;
  contactTags?: Array<{ tag: { name: string } }>;
}

export const aiService = {
  async classifyContact(contact: ContactForAI): Promise<ClassifyResult> {
    const platformSummary = contact.platforms
      .map((p) => `${p.type}${p.displayName ? ` (${p.displayName})` : ""}`)
      .join(", ");

    const recentInteractions = contact.interactions
      .slice(0, 10)
      .map(
        (i) =>
          `[${i.occurredAt.toISOString().slice(0, 10)}] ${i.platform} ${i.direction}${i.contentSnippet ? `: ${i.contentSnippet.slice(0, 200)}` : ""}`
      )
      .join("\n");

    const response = await anthropic.messages.create({
      model: CHAT_MODEL,
      max_tokens: 1024,
      tools: [
        {
          name: "classify_contact",
          description:
            "Classify a contact by type and domain based on their profile and interactions.",
          input_schema: {
            type: "object" as const,
            properties: {
              type: {
                type: "string",
                enum: [
                  "vc",
                  "lead",
                  "partner",
                  "friend",
                  "prospect",
                  "team",
                  "advisor",
                  "media",
                  "other",
                ],
                description: "The primary type/role of this contact.",
              },
              domain: {
                type: "string",
                enum: [
                  "payment",
                  "blockchain",
                  "saas",
                  "ecommerce",
                  "ai",
                  "marketing",
                  "legal",
                  "finance",
                  "other",
                ],
                description: "The industry/domain this contact operates in.",
              },
              confidence: {
                type: "number",
                minimum: 0,
                maximum: 1,
                description:
                  "Confidence score between 0 and 1 for this classification.",
              },
            },
            required: ["type", "domain", "confidence"],
          },
        },
      ],
      tool_choice: { type: "tool", name: "classify_contact" },
      messages: [
        {
          role: "user",
          content: `Classify this contact based on the available information.

Name: ${contact.name}
Company: ${contact.company || "Unknown"}
Role: ${contact.role || "Unknown"}
Platforms: ${platformSummary || "None"}

Recent interactions:
${recentInteractions || "No interactions yet"}

Use the classify_contact tool to provide the classification.`,
        },
      ],
    });

    const toolBlock = response.content.find((b) => b.type === "tool_use");
    if (!toolBlock || toolBlock.type !== "tool_use") {
      throw new Error("AI did not return a classification");
    }

    return toolBlock.input as ClassifyResult;
  },

  async generateSummary(contact: ContactForAI): Promise<string> {
    const platformSummary = contact.platforms
      .map((p) => `${p.type}${p.displayName ? ` (${p.displayName})` : ""}`)
      .join(", ");

    const recentInteractions = contact.interactions
      .slice(0, 20)
      .map(
        (i) =>
          `[${i.occurredAt.toISOString().slice(0, 10)}] ${i.platform} ${i.direction}${i.contentSnippet ? `: ${i.contentSnippet.slice(0, 200)}` : ""}`
      )
      .join("\n");

    const notes = (contact.notes || [])
      .slice(0, 10)
      .map((n) => `- ${n.content.slice(0, 300)}`)
      .join("\n");

    const tags = (contact.contactTags || [])
      .map((ct) => ct.tag.name)
      .join(", ");

    const response = await anthropic.messages.create({
      model: CHAT_MODEL,
      max_tokens: 1024,
      messages: [
        {
          role: "user",
          content: `Write a concise professional summary (2-4 sentences) for this contact in the Suby CRM. Focus on who they are, the relationship status, and any key points.

Name: ${contact.name}
Company: ${contact.company || "Unknown"}
Role: ${contact.role || "Unknown"}
Platforms: ${platformSummary || "None"}
Tags: ${tags || "None"}

Recent interactions:
${recentInteractions || "No interactions yet"}

Notes:
${notes || "No notes"}

Return ONLY the summary text, no headers or formatting.`,
        },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (!textBlock || textBlock.type !== "text") {
      throw new Error("AI did not return a summary");
    }

    return textBlock.text;
  },

  async generatePrep(contact: ContactForAI): Promise<{
    summary: string;
    talkingPoints: string[];
    recentActivity: string;
    suggestedActions: string[];
  }> {
    const platformSummary = contact.platforms.map(p => `${p.type}${p.displayName ? ` (${p.displayName})` : ""}`).join(", ");
    const interactions = contact.interactions.slice(0, 20).map(i =>
      `[${i.occurredAt.toISOString().slice(0, 10)}] ${i.platform} ${i.direction}${i.contentSnippet ? `: ${i.contentSnippet.slice(0, 200)}` : ""}`
    ).join("\n");
    const notes = (contact.notes || []).slice(0, 10).map(n => `- ${n.content.slice(0, 300)}`).join("\n");
    const tags = (contact.contactTags || []).map(ct => ct.tag.name).join(", ");

    const response = await anthropic.messages.create({
      model: CHAT_MODEL,
      max_tokens: 2048,
      tools: [{
        name: "meeting_prep",
        description: "Generate a structured meeting preparation briefing",
        input_schema: {
          type: "object" as const,
          properties: {
            summary: { type: "string", description: "2-3 sentence summary of who this person is and your relationship" },
            talkingPoints: { type: "array", items: { type: "string" }, description: "3-5 suggested talking points for the meeting" },
            recentActivity: { type: "string", description: "Summary of recent interactions and what was discussed" },
            suggestedActions: { type: "array", items: { type: "string" }, description: "2-3 suggested actions or follow-ups" },
          },
          required: ["summary", "talkingPoints", "recentActivity", "suggestedActions"],
        },
      }],
      tool_choice: { type: "tool", name: "meeting_prep" },
      messages: [{
        role: "user",
        content: `Generate a meeting preparation briefing for an upcoming call with this contact.

Name: ${contact.name}
Company: ${contact.company || "Unknown"}
Role: ${contact.role || "Unknown"}
Platforms: ${platformSummary}
Tags: ${tags || "None"}

Recent interactions:
${interactions || "No recent interactions"}

Notes:
${notes || "No notes"}

Use the meeting_prep tool to provide the structured briefing.`,
      }],
    });

    const toolBlock = response.content.find(b => b.type === "tool_use");
    if (!toolBlock || toolBlock.type !== "tool_use") {
      return { summary: `Prep for ${contact.name}`, talkingPoints: [], recentActivity: "No data", suggestedActions: [] };
    }
    return toolBlock.input as any;
  },

  async getAlerts(): Promise<Array<{ type: string; message: string; contactId?: string; contactName?: string }>> {
    const { prisma } = await import("../lib/prisma");
    const alerts: Array<{ type: string; message: string; contactId?: string; contactName?: string }> = [];
    const now = Date.now();
    const thirtyDays = 30 * 24 * 60 * 60 * 1000;

    // Stale VCs (high priority)
    const staleVCs = await prisma.contact.findMany({
      where: { type: "vc", lastContactDate: { lt: new Date(now - thirtyDays) } },
      orderBy: { lastContactDate: "asc" },
      take: 5,
    });
    for (const vc of staleVCs) {
      const days = vc.lastContactDate ? Math.floor((now - vc.lastContactDate.getTime()) / (24 * 60 * 60 * 1000)) : 999;
      alerts.push({ type: "stale_vc", message: `${vc.name} (VC) - no contact in ${days} days`, contactId: vc.id, contactName: vc.name });
    }

    // Hot contacts going cold
    const coolingHot = await prisma.contact.findMany({
      where: { relationshipStrength: "hot", lastContactDate: { lt: new Date(now - 14 * 24 * 60 * 60 * 1000) } },
      take: 5,
    });
    for (const c of coolingHot) {
      alerts.push({ type: "cooling", message: `${c.name} is hot but no contact in 14+ days`, contactId: c.id, contactName: c.name });
    }

    // Stale partners
    const stalePartners = await prisma.contact.findMany({
      where: { type: "partner", lastContactDate: { lt: new Date(now - thirtyDays) } },
      take: 3,
    });
    for (const p of stalePartners) {
      alerts.push({ type: "stale_partner", message: `${p.name} (Partner) - needs follow-up`, contactId: p.id, contactName: p.name });
    }

    return alerts;
  },
};
