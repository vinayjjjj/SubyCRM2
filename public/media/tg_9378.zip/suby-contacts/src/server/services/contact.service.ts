import { prisma } from "../lib/prisma";
import type { Prisma } from "@prisma/client";

export const contactService = {
  async getAll(filters: {
    type?: string;
    domain?: string;
    strength?: string;
    tag?: string;
    search?: string;
    stale_days?: number;
    page?: number;
    limit?: number;
  } = {}) {
    const page = filters.page ?? 0;
    const limit = filters.limit ?? 20;
    const where: Prisma.ContactWhereInput = {};

    if (filters.type) where.type = filters.type as any;
    if (filters.domain) where.domain = filters.domain as any;
    if (filters.strength) where.relationshipStrength = filters.strength as any;

    if (filters.search) {
      where.OR = [
        { name: { contains: filters.search, mode: "insensitive" } },
        { company: { contains: filters.search, mode: "insensitive" } },
      ];
    }

    if (filters.tag) {
      where.contactTags = { some: { tag: { name: filters.tag } } };
    }

    if (filters.stale_days) {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - filters.stale_days);
      where.OR = [
        ...(where.OR ? (where.OR as Prisma.ContactWhereInput[]) : []),
      ];
      // Stale = lastContactDate before cutoff OR null
      where.AND = [
        {
          OR: [
            { lastContactDate: { lt: cutoff } },
            { lastContactDate: null },
          ],
        },
      ];
    }

    const [contacts, total] = await Promise.all([
      prisma.contact.findMany({
        where,
        orderBy: { lastContactDate: { sort: "desc", nulls: "last" } },
        skip: page * limit,
        take: limit,
        include: {
          platforms: { select: { type: true, platformId: true, displayName: true } },
          _count: { select: { platforms: true } },
          interactions: {
            orderBy: { occurredAt: "desc" },
            take: 1,
            select: { occurredAt: true, platform: true },
          },
          contactTags: {
            include: { tag: true },
          },
        },
      }),
      prisma.contact.count({ where }),
    ]);

    return {
      data: contacts.map((c) => ({
        ...c,
        platforms: c.platforms,
        platformsCount: c._count.platforms,
        lastInteraction: c.interactions[0] || null,
        _count: undefined,
        interactions: undefined,
      })),
      total,
      page,
      limit,
    };
  },

  async getStats() {
    const now = new Date();
    const d30 = new Date(now); d30.setDate(d30.getDate() - 30);
    const d60 = new Date(now); d60.setDate(d60.getDate() - 60);
    const d90 = new Date(now); d90.setDate(d90.getDate() - 90);

    const [total, byType, byDomain, byStrength, stale30, stale60, stale90] =
      await Promise.all([
        prisma.contact.count(),
        prisma.contact.groupBy({ by: ["type"], _count: true }),
        prisma.contact.groupBy({ by: ["domain"], _count: true }),
        prisma.contact.groupBy({ by: ["relationshipStrength"], _count: true }),
        prisma.contact.count({
          where: { OR: [{ lastContactDate: { lt: d30 } }, { lastContactDate: null }] },
        }),
        prisma.contact.count({
          where: { OR: [{ lastContactDate: { lt: d60 } }, { lastContactDate: null }] },
        }),
        prisma.contact.count({
          where: { OR: [{ lastContactDate: { lt: d90 } }, { lastContactDate: null }] },
        }),
      ]);

    return {
      total,
      byType: Object.fromEntries(byType.map((r) => [r.type, r._count])),
      byDomain: Object.fromEntries(byDomain.map((r) => [r.domain, r._count])),
      byStrength: Object.fromEntries(byStrength.map((r) => [r.relationshipStrength, r._count])),
      stale30,
      stale60,
      stale90,
    };
  },

  async getById(id: string) {
    return prisma.contact.findUnique({
      where: { id },
      include: {
        platforms: true,
        notes: { orderBy: { createdAt: "desc" }, take: 20 },
        contactTags: { include: { tag: true } },
        interactions: { orderBy: { occurredAt: "desc" }, take: 50 },
      },
    });
  },

  async create(data: {
    name: string;
    type?: string;
    domain?: string;
    company?: string;
    role?: string;
    relationshipStrength?: string;
    platforms?: Array<{
      type: string;
      platformId: string;
      displayName?: string;
      profileUrl?: string;
    }>;
  }) {
    const { platforms, ...contactData } = data;
    return prisma.contact.create({
      data: {
        ...contactData as any,
        platforms: platforms?.length
          ? { create: platforms as any }
          : undefined,
      },
      include: { platforms: true },
    });
  },

  async update(id: string, data: Record<string, unknown>) {
    // Strip relations from update
    const { platforms, notes, contactTags, interactions, ...fields } = data;
    return prisma.contact.update({
      where: { id },
      data: fields as any,
      include: { platforms: true },
    });
  },

  async delete(id: string) {
    return prisma.contact.delete({ where: { id } });
  },

  async merge(keepId: string, mergeWithId: string) {
    // Move all related records from mergeWithId to keepId, then delete mergeWithId
    return prisma.$transaction(async (tx) => {
      // Move platforms (skip duplicates by catching unique constraint errors)
      await tx.platform.updateMany({
        where: { contactId: mergeWithId },
        data: { contactId: keepId },
      });

      // Move interactions
      await tx.interaction.updateMany({
        where: { contactId: mergeWithId },
        data: { contactId: keepId },
      });

      // Move notes
      await tx.note.updateMany({
        where: { contactId: mergeWithId },
        data: { contactId: keepId },
      });

      // Move tags (delete duplicates first)
      const existingTags = await tx.contactTag.findMany({
        where: { contactId: keepId },
        select: { tagId: true },
      });
      const existingTagIds = new Set(existingTags.map((t) => t.tagId));

      // Delete tags on mergeWith that already exist on keep
      await tx.contactTag.deleteMany({
        where: {
          contactId: mergeWithId,
          tagId: { in: Array.from(existingTagIds) },
        },
      });

      // Move remaining tags
      await tx.contactTag.updateMany({
        where: { contactId: mergeWithId },
        data: { contactId: keepId },
      });

      // Update lastContactDate on keep contact to the most recent
      const mergedContact = await tx.contact.findUnique({
        where: { id: mergeWithId },
        select: { lastContactDate: true, firstContactDate: true },
      });

      if (mergedContact) {
        const keepContact = await tx.contact.findUnique({
          where: { id: keepId },
          select: { lastContactDate: true, firstContactDate: true },
        });

        const updates: Record<string, Date> = {};
        if (
          mergedContact.lastContactDate &&
          (!keepContact?.lastContactDate || mergedContact.lastContactDate > keepContact.lastContactDate)
        ) {
          updates.lastContactDate = mergedContact.lastContactDate;
        }
        if (
          mergedContact.firstContactDate &&
          (!keepContact?.firstContactDate || mergedContact.firstContactDate < keepContact.firstContactDate)
        ) {
          updates.firstContactDate = mergedContact.firstContactDate;
        }

        if (Object.keys(updates).length > 0) {
          await tx.contact.update({ where: { id: keepId }, data: updates });
        }
      }

      // Delete the merged contact
      await tx.contact.delete({ where: { id: mergeWithId } });

      // Return the updated keep contact
      return tx.contact.findUnique({
        where: { id: keepId },
        include: {
          platforms: true,
          notes: { orderBy: { createdAt: "desc" }, take: 20 },
          contactTags: { include: { tag: true } },
          interactions: { orderBy: { occurredAt: "desc" }, take: 50 },
        },
      });
    });
  },
};
