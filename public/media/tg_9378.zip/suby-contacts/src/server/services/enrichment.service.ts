import { prisma } from "../lib/prisma";

const SERPAPI_KEY = process.env.SERPAPI_KEY || "a6051d4480e440562821d8cbf4ae581b7cf80b5cc5cf518ae5094ab9bae01a07";

interface SerpResult {
  organic_results?: Array<{
    title?: string;
    snippet?: string;
    link?: string;
  }>;
}

async function serpSearch(query: string): Promise<SerpResult> {
  const url = new URL("https://serpapi.com/search.json");
  url.searchParams.set("q", query);
  url.searchParams.set("api_key", SERPAPI_KEY);
  url.searchParams.set("num", "3");
  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`SerpAPI error: ${res.status}`);
  return res.json();
}

function extractLinkedInInfo(results: SerpResult): {
  fullName?: string;
  company?: string;
  role?: string;
  bio?: string;
} {
  const top = results.organic_results?.[0];
  if (!top) return {};

  const info: { fullName?: string; company?: string; role?: string; bio?: string } = {};

  // Title often has "FirstName LastName - Role - Company | LinkedIn"
  if (top.title) {
    const titleParts = top.title.replace(/\s*\|\s*LinkedIn.*$/i, "").split(/\s*[-–]\s*/);
    if (titleParts.length >= 1) info.fullName = titleParts[0].trim();
    if (titleParts.length >= 2) info.role = titleParts[1].trim();
    if (titleParts.length >= 3) info.company = titleParts[2].trim();
  }

  if (top.snippet) {
    info.bio = top.snippet;
    // Try to extract company/role from snippet if not found in title
    if (!info.company) {
      const companyMatch = top.snippet.match(/(?:at|@)\s+([A-Z][A-Za-z0-9\s&.]+?)(?:\s*[·|,.]|\s+and\s|\s+in\s|$)/);
      if (companyMatch) info.company = companyMatch[1].trim();
    }
    if (!info.role) {
      const roleMatch = top.snippet.match(/(CEO|CTO|COO|CFO|Founder|Co-Founder|Director|VP|Manager|Engineer|Developer|Designer|Head of [A-Za-z]+)/i);
      if (roleMatch) info.role = roleMatch[1].trim();
    }
  }

  return info;
}

function extractTwitterInfo(results: SerpResult): {
  bio?: string;
  followers?: string;
} {
  const top = results.organic_results?.[0];
  if (!top) return {};

  const info: { bio?: string; followers?: string } = {};

  if (top.snippet) {
    info.bio = top.snippet;
    const followMatch = top.snippet.match(/([\d.]+[KMkm]?\s*[Ff]ollowers)/);
    if (followMatch) info.followers = followMatch[1];
  }

  return info;
}

export const enrichmentService = {
  async enrichContact(contactId: string) {
    const contact = await prisma.contact.findUnique({
      where: { id: contactId },
      include: { platforms: true },
    });

    if (!contact) throw new Error("Contact not found");

    const enrichedData: {
      fullName?: string;
      company?: string;
      role?: string;
      bio?: string;
      followers?: string;
      linkedinSnippet?: string;
      twitterSnippet?: string;
    } = {};

    // Enrich from LinkedIn
    const linkedinPlatform = contact.platforms.find((p) => p.type === "linkedin");
    if (linkedinPlatform) {
      try {
        const results = await serpSearch(`site:linkedin.com "${linkedinPlatform.platformId}"`);
        const linkedinInfo = extractLinkedInInfo(results);
        if (linkedinInfo.fullName) enrichedData.fullName = linkedinInfo.fullName;
        if (linkedinInfo.company) enrichedData.company = linkedinInfo.company;
        if (linkedinInfo.role) enrichedData.role = linkedinInfo.role;
        if (linkedinInfo.bio) enrichedData.linkedinSnippet = linkedinInfo.bio;
      } catch (err) {
        console.error("[enrichment] LinkedIn search failed:", err);
      }
    }

    // Enrich from X/Twitter
    const xPlatform = contact.platforms.find((p) => p.type === "x");
    if (xPlatform) {
      try {
        const results = await serpSearch(`site:x.com "${xPlatform.platformId}"`);
        const twitterInfo = extractTwitterInfo(results);
        if (twitterInfo.bio) enrichedData.twitterSnippet = twitterInfo.bio;
        if (twitterInfo.followers) enrichedData.followers = twitterInfo.followers;
        // If no bio from LinkedIn, use twitter bio
        if (!enrichedData.bio && twitterInfo.bio) enrichedData.bio = twitterInfo.bio;
      } catch (err) {
        console.error("[enrichment] X/Twitter search failed:", err);
      }
    }

    // Update contact with found role/company
    const updateData: Record<string, unknown> = {};
    if (enrichedData.role && !contact.role) updateData.role = enrichedData.role;
    if (enrichedData.company && !contact.company) updateData.company = enrichedData.company;

    // If company name found, upsert Company record and link it
    let companyRecord = null;
    if (enrichedData.company) {
      companyRecord = await prisma.company.upsert({
        where: { name: enrichedData.company },
        create: { name: enrichedData.company },
        update: {},
      });
      if (!contact.companyId) {
        updateData.companyId = companyRecord.id;
      }
    }

    if (Object.keys(updateData).length > 0) {
      await prisma.contact.update({
        where: { id: contactId },
        data: updateData,
      });
    }

    return {
      contactId,
      enrichedData,
      companyLinked: companyRecord ? { id: companyRecord.id, name: companyRecord.name } : null,
    };
  },
};
